"""
generate_dataset.py
===================
Synthetic Retail Enterprise Dataset Generator for Bayesian Hierarchical Sales Forecasting.
Generates a realistic multi-store, multi-category retail dataset across 3 years (2021-2023)
with trend, annual/quarterly/monthly seasonality, promotional lift, holiday spikes,
inventory parameters, and lead-time stochasticity.

NOTE: This dataset is a realistic benchmark synthetic dataset designed for academic research
and algorithm verification. It is clearly labeled as synthetic in compliance with academic
integrity guidelines.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import os

def generate_retail_sales_data(
    start_date: str = "2021-01-04",  # Monday
    num_weeks: int = 156,             # 3 full years of weekly observations
    random_seed: int = 42
) -> pd.DataFrame:
    """
    Generate synthetic weekly retail sales dataset with realistic hierarchical structure.
    
    Hierarchy:
      - 4 Stores (different location footprints, sizes, and customer bases)
      - 4 Product Categories (Groceries, Electronics, Apparel, Home & Living)
      - 12 Representative SKUs (3 per category)
    """
    np.random.seed(random_seed)
    
    stores = [
        {"store_id": "STR_01", "store_name": "Metro Hypermarket (Downtown)", "base_multiplier": 1.45, "traffic_volatility": 0.08},
        {"store_id": "STR_02", "store_name": "Suburban Supercenter (Westfield)", "base_multiplier": 1.20, "traffic_volatility": 0.06},
        {"store_id": "STR_03", "store_name": "Urban Express (Central Hub)", "base_multiplier": 0.85, "traffic_volatility": 0.12},
        {"store_id": "STR_04", "store_name": "Regional Outlet (South Mall)", "base_multiplier": 0.95, "traffic_volatility": 0.10},
    ]
    
    products = [
        # Groceries & Fresh (High velocity, low margin, low lead time)
        {"product_id": "PRD_GROC_01", "product_name": "Organic Milk & Dairy Pack", "category": "Groceries & Fresh",
         "base_price": 5.50, "base_demand": 420, "lead_time_days": 4, "holding_cost": 0.35, "stockout_cost": 4.00, "promo_elasticity": 1.4},
        {"product_id": "PRD_GROC_02", "product_name": "Artisan Sourdough Loaf", "category": "Groceries & Fresh",
         "base_price": 4.25, "base_demand": 310, "lead_time_days": 3, "holding_cost": 0.25, "stockout_cost": 3.00, "promo_elasticity": 1.2},
        {"product_id": "PRD_GROC_03", "product_name": "Arabica Coffee Beans 500g", "category": "Groceries & Fresh",
         "base_price": 12.99, "base_demand": 190, "lead_time_days": 7, "holding_cost": 0.60, "stockout_cost": 8.50, "promo_elasticity": 1.6},
        
        # Electronics & Gadgets (Lower velocity, high margin, longer lead time, strong Q4 seasonality)
        {"product_id": "PRD_ELEC_01", "product_name": "Noise-Cancelling Headphones", "category": "Electronics & Gadgets",
         "base_price": 149.99, "base_demand": 45, "lead_time_days": 21, "holding_cost": 3.50, "stockout_cost": 45.00, "promo_elasticity": 2.2},
        {"product_id": "PRD_ELEC_02", "product_name": "Smart Fitness Watch Gen-2", "category": "Electronics & Gadgets",
         "base_price": 99.50, "base_demand": 60, "lead_time_days": 18, "holding_cost": 2.20, "stockout_cost": 30.00, "promo_elasticity": 2.0},
        {"product_id": "PRD_ELEC_03", "product_name": "Ultra-Fast Power Bank 20000mAh", "category": "Electronics & Gadgets",
         "base_price": 39.99, "base_demand": 85, "lead_time_days": 14, "holding_cost": 1.10, "stockout_cost": 15.00, "promo_elasticity": 1.8},
        
        # Apparel & Fashion (Moderate velocity, high seasonal shifts)
        {"product_id": "PRD_APPR_01", "product_name": "Classic Stretch Denim Jeans", "category": "Apparel & Fashion",
         "base_price": 54.00, "base_demand": 95, "lead_time_days": 14, "holding_cost": 1.25, "stockout_cost": 20.00, "promo_elasticity": 1.9},
        {"product_id": "PRD_APPR_02", "product_name": "Breathable Running Sneakers", "category": "Apparel & Fashion",
         "base_price": 79.00, "base_demand": 75, "lead_time_days": 16, "holding_cost": 1.80, "stockout_cost": 25.00, "promo_elasticity": 1.7},
        {"product_id": "PRD_APPR_03", "product_name": "Organic Fleece Pullover Hoodie", "category": "Apparel & Fashion",
         "base_price": 45.00, "base_demand": 80, "lead_time_days": 14, "holding_cost": 1.00, "stockout_cost": 18.00, "promo_elasticity": 2.1},
        
        # Home & Living (Steady demand with spring/autumn peaks)
        {"product_id": "PRD_HOME_01", "product_name": "Pre-Seasoned Cast Iron Skillet", "category": "Home & Living",
         "base_price": 36.50, "base_demand": 65, "lead_time_days": 12, "holding_cost": 0.90, "stockout_cost": 14.00, "promo_elasticity": 1.5},
        {"product_id": "PRD_HOME_02", "product_name": "Ergonomic Memory Foam Pillow", "category": "Home & Living",
         "base_price": 42.00, "base_demand": 70, "lead_time_days": 10, "holding_cost": 1.05, "stockout_cost": 16.00, "promo_elasticity": 1.4},
        {"product_id": "PRD_HOME_03", "product_name": "Dimmable LED Architect Lamp", "category": "Home & Living",
         "base_price": 28.50, "base_demand": 55, "lead_time_days": 14, "holding_cost": 0.75, "stockout_cost": 12.00, "promo_elasticity": 1.3},
    ]
    
    start_dt = pd.to_datetime(start_date)
    dates = [start_dt + timedelta(weeks=w) for w in range(num_weeks)]
    
    records = []
    
    for dt in dates:
        week_num = dt.isocalendar()[1]
        year = dt.year
        month = dt.month
        t = (dt - start_dt).days / 365.25  # continuous years elapsed
        
        # Retail calendar effects:
        # Annual Fourier components (Harmonic 1 and Harmonic 2)
        annual_phase = 2 * np.pi * ((dt.dayofyear - 1) / 365.25)
        seasonal_annual = 0.18 * np.sin(annual_phase - 1.2) + 0.10 * np.cos(2 * annual_phase)
        
        # Major retail holiday weeks:
        # Week ~47-48: Thanksgiving / Black Friday / Cyber Monday (heavy surge)
        # Week ~51-52: Christmas / Year-end gifting
        # Week ~14-16: Easter / Spring promotional week
        # Week ~28-29: Mid-summer / Prime discount festival
        is_holiday = 0
        holiday_multiplier = 1.0
        
        if week_num in [47, 48]:  # Black Friday week
            is_holiday = 1
            holiday_multiplier = 1.65
        elif week_num in [51, 52]:  # Christmas / Holiday Peak
            is_holiday = 1
            holiday_multiplier = 1.80
        elif week_num in [14, 15]:  # Easter / Spring
            is_holiday = 1
            holiday_multiplier = 1.25
        elif week_num in [28, 29]:  # Mid-year sale
            is_holiday = 1
            holiday_multiplier = 1.30
        elif week_num in [35, 36]:  # Back to school / Labor day
            is_holiday = 1
            holiday_multiplier = 1.20
            
        # Overall economic growth / macro trend (+4.5% annual growth)
        macro_trend = 1.0 + 0.045 * t
        
        for store in stores:
            store_mult = store["base_multiplier"]
            store_vol = store["traffic_volatility"]
            
            for prod in products:
                cat = prod["category"]
                
                # Category-specific seasonality modulation
                cat_season_mult = 1.0
                if cat == "Electronics & Gadgets":
                    # Heavy Q4 concentration
                    cat_season_mult = 1.45 if month in [11, 12] else (0.90 if month in [1, 2] else 0.98)
                elif cat == "Apparel & Fashion":
                    # Spring & Winter collection peaks
                    cat_season_mult = 1.25 if month in [4, 5, 11, 12] else 0.88
                elif cat == "Home & Living":
                    # Steady with autumn/spring home improvement
                    cat_season_mult = 1.15 if month in [3, 4, 9, 10] else 0.95
                elif cat == "Groceries & Fresh":
                    # Highly resilient baseline demand
                    cat_season_mult = 1.08 if month in [11, 12] else 0.98
                    
                # Promotional assignment (random probabilistic with higher probability on holidays)
                promo_prob = 0.35 if is_holiday else 0.15
                on_promo = 1 if np.random.rand() < promo_prob else 0
                
                if on_promo:
                    discount_pct = float(np.random.choice([0.10, 0.15, 0.20, 0.25, 0.30]))
                    promo_boost = 1.0 + (discount_pct * prod["promo_elasticity"] * 2.2)
                else:
                    discount_pct = 0.0
                    promo_boost = 1.0
                    
                # Actual unit selling price
                effective_price = round(prod["base_price"] * (1.0 - discount_pct), 2)
                
                # True underlying mean demand
                mean_demand = (
                    prod["base_demand"]
                    * store_mult
                    * macro_trend
                    * (1.0 + seasonal_annual)
                    * cat_season_mult
                    * holiday_multiplier
                    * promo_boost
                )
                
                # Stochastic realization: Negative Binomial or Poisson-like with overdispersion
                noise = np.random.normal(0, store_vol * mean_demand)
                raw_units = mean_demand + noise
                units_sold = max(0, int(np.round(raw_units)))
                
                # Revenue
                revenue = round(units_sold * effective_price, 2)
                
                # Stock on hand simulation (inventory balance)
                safety_buffer = int(prod["base_demand"] * store_mult * 1.5)
                simulated_stock = max(units_sold + int(np.random.normal(safety_buffer, safety_buffer * 0.2)), units_sold)
                
                # Intermittent zero handling: randomly set 0.3% of low-velocity records to 0
                if cat != "Groceries & Fresh" and np.random.rand() < 0.005:
                    units_sold = 0
                    revenue = 0.0
                
                records.append({
                    "date": dt.strftime("%Y-%m-%d"),
                    "year": year,
                    "month": month,
                    "week": week_num,
                    "store_id": store["store_id"],
                    "store_name": store["store_name"],
                    "category": prod["category"],
                    "product_id": prod["product_id"],
                    "product_name": prod["product_name"],
                    "unit_price": effective_price,
                    "base_price": prod["base_price"],
                    "units_sold": units_sold,
                    "revenue": revenue,
                    "on_promotion": on_promo,
                    "discount_percent": discount_pct,
                    "holiday_flag": is_holiday,
                    "stock_on_hand": simulated_stock,
                    "lead_time_days": prod["lead_time_days"],
                    "holding_cost_per_unit": prod["holding_cost"],
                    "stockout_cost_per_unit": prod["stockout_cost"]
                })
                
    df = pd.DataFrame(records)
    return df

if __name__ == "__main__":
    out_dir = os.path.dirname(os.path.abspath(__file__))
    df = generate_retail_sales_data(start_date="2021-01-04", num_weeks=156, random_seed=42)
    csv_path = os.path.join(out_dir, "retail_sales_sample.csv")
    df.to_csv(csv_path, index=False)
    print(f"Generated realistic retail sales dataset with {len(df)} rows and {len(df.columns)} columns.")
    print(f"Saved to: {csv_path}")
    print(f"Date range: {df['date'].min()} to {df['date'].max()}")
    print("Categories:", df['category'].unique())
    print("Stores:", df['store_name'].unique())
