# Software Architecture & System Design

**Project Title:** Sales and Revenue Forecasting with Seasonality via Bayesian Hierarchical Modeling for Uncertainty Quantification, Applied to Retail Demand Planning and Inventory Optimization  
**Project Guide:** Dr. P. Sudhakar  
**Tech Stack:** Python 3.12+, Pandas, NumPy, PyMC, ArviZ, Scikit-learn, Statsmodels, Plotly, Streamlit  

---

## 1. High-Level System Architecture

The RetailBayes AI platform is architected around a decoupled, 4-tier modular pipeline designed for computational efficiency, probabilistic uncertainty quantification, and interactive decision support:

```
[ Tier 1: Ingestion & Validation ]
       │
       ▼
[ Tier 2: Feature Engineering & Preprocessing ]
       │
       ▼
[ Tier 3: Statistical Modeling & Optimization Core ]
  ├── PyMC Bayesian Hierarchical Forecaster (MCMC & ADVI)
  ├── Classical Baselines (Ridge, Random Forest, Holt-Winters)
  ├── Multi-scale Seasonality & Fourier Spectrum
  └── Bayesian & Classical Inventory Optimization Engine
       │
       ▼
[ Tier 4: Interactive Streamlit UI / Dashboard ]
```

---

## 2. Directory Layout & Module Responsibilities

```
Sales_Revenue_Forecasting/
├── .streamlit/
│   └── config.toml             # Dark theme, typography & server config
├── data/
│   ├── generate_dataset.py     # Realistic synthetic benchmark generator
│   └── retail_sales_sample.csv # 7,488 records (3 years, 4 stores, 4 categories)
├── docs/
│   ├── ARCHITECTURE.md         # System architecture & data flow (this file)
│   ├── MATHEMATICAL_FORMULATION.md # Full probabilistic formulations & proofs
│   └── PROJECT_REPORT.md       # B.Tech major project final academic report
├── src/
│   ├── __init__.py
│   ├── data_processing.py      # Schema validation, missing value imputation, Fourier features
│   ├── bayesian_model.py       # PyMC Hierarchical model, NUTS/ADVI, posterior sampling
│   ├── baseline_models.py      # RidgeCV, Random Forest, Holt-Winters Exponential Smoothing
│   ├── seasonality.py          # 4-component classical decomposition, monthly/quarterly index, FFT
│   ├── inventory.py            # Bayesian quantile ROP, Safety Stock, EOQ, Trajectory simulator
│   ├── evaluation.py           # MAE, RMSE, wMAPE, MAPE (zero-handled), 80/95% CI coverage
│   └── visualization.py        # Dark-themed Plotly charts with credible ribbons
├── tests/
│   ├── __init__.py
│   ├── test_data_processing.py # Unit tests for data ingestion & features
│   ├── test_models.py          # Unit tests for Bayesian & baseline forecasters
│   ├── test_inventory.py       # Unit tests for safety stock, ROP, simulation
│   └── test_evaluation.py      # Unit tests for evaluation metrics & zero-handling
├── app.py                      # Production-grade 9-page Streamlit Dashboard
├── run_tests.py                # Automated test runner script
├── requirements.txt            # Production dependencies
├── .gitignore
└── README.md                   # Setup, execution & user guide
```

---

## 3. Data Flow & Execution Pipeline

```mermaid
sequenceDiagram
    autonumber
    actor User as Retail Planner
    participant UI as Streamlit Dashboard (app.py)
    participant DP as Data Processing (data_processing.py)
    participant BM as Bayesian Engine (bayesian_model.py)
    participant BL as Baseline Engine (baseline_models.py)
    participant Inv as Inventory Engine (inventory.py)
    
    User->>UI: Selects Target Metric & Forecast Horizon
    UI->>DP: Request Aggregation & Fourier Feature Pipeline
    DP-->>UI: Train / Test Matrices with Cyclical Features
    User->>UI: Triggers "Fit Bayesian Model"
    UI->>BM: Fit Model (NUTS or ADVI) & Sample Posterior
    BM-->>UI: Posterior Draws + 50%, 80%, 95% Credible Ribbons
    User->>UI: Views Model Benchmark
    UI->>BL: Fit Ridge, RF, Holt-Winters
    BL-->>UI: Side-by-Side MAE, RMSE, wMAPE, Coverage Table
    User->>UI: Selects Service Level (e.g. 95%) in Inventory Tab
    UI->>Inv: Compute Bayesian ROP & Lead-Time Demand Quantile
    Inv-->>UI: Safety Stock, ROP, EOQ & Simulated Stockout Trajectory
```

---

## 4. Caching & Performance Design

1. **`@st.cache_data`**: Used for reading and validating CSV files, preventing repeated disk I/O on page switching.
2. **`@st.cache_resource` / Session State**: Trained Bayesian models and posterior predictive matrices are preserved in `st.session_state` to prevent expensive re-sampling when switching between visualization pages.
3. **Dual Inference Mode**:
   - **ADVI (Mean-Field Variational Inference):** Executes in ~2-4 seconds for rapid exploratory forecasting.
   - **NUTS (No-U-Turn Sampler):** Full Hamiltonian MCMC execution for high-precision academic research and publication-grade credible intervals.
