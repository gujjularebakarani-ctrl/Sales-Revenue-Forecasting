# Mathematical Formulation & Bayesian Statistical Theory

**Project Title:** Sales and Revenue Forecasting with Seasonality via Bayesian Hierarchical Modeling for Uncertainty Quantification, Applied to Retail Demand Planning and Inventory Optimization  
**Project Guide:** Dr. P. Sudhakar  

---

## 1. Probabilistic Generative Model

In retail demand systems, observations exhibit multiple layers of hierarchy, non-linear seasonal cycles, promotional shocks, and heavy-tailed disturbances.

We specify a **Bayesian Hierarchical Generalized Additive Model** with a robust Student-t likelihood:

$$y_{s,c,t} \sim \text{StudentT}\left(\nu, \; \mu_{s,c,t}, \; \sigma_{\text{obs}}\right)$$

where:
- $s \in \{1, \dots, S\}$ denotes the Store identifier.
- $c \in \{1, \dots, C\}$ denotes the Product Category identifier.
- $t \in [0, T]$ represents the normalized continuous time index in years.
- $\nu$ is the degrees-of-freedom parameter governing tail thickness (protecting against promotional outliers).
- $\sigma_{\text{obs}}$ is the residual scale parameter.

---

## 2. Linear Predictor & Hierarchical Structure

The location parameter $\mu_{s,c,t}$ is decomposed additively:

$$\mu_{s,c,t} = \alpha_0 + \alpha_{\text{store}[s]} + \alpha_{\text{cat}[c]} + \beta_{\text{trend}} \cdot t + \beta_{\text{promo}} \cdot \text{Promo}_t + \beta_{\text{holiday}} \cdot \text{Holiday}_t + S(t)$$

### 2.1 Hyperpriors & Partial Pooling (Shrinkage)
To balance between underfitting (complete pooling) and overfitting (no pooling), we assign hierarchical priors:

$$\alpha_0 \sim \mathcal{N}(0, 1.0)$$

$$\sigma_{\text{store}} \sim \text{HalfNormal}(0.5), \quad \alpha_{\text{store}[s]} \sim \mathcal{N}(0, \sigma_{\text{store}})$$

$$\sigma_{\text{cat}} \sim \text{HalfNormal}(0.5), \quad \alpha_{\text{cat}[c]} \sim \mathcal{N}(0, \sigma_{\text{cat}})$$

- As sample size $N_s \to 0$ for a small store, $\alpha_{\text{store}[s]}$ shrinks strongly toward zero (the global average).
- For large stores with abundant data, $\alpha_{\text{store}[s]}$ reflects their empirical volume.

### 2.2 Trend & Intervention Effects
$$\beta_{\text{trend}} \sim \mathcal{N}(0, 0.5)$$
$$\beta_{\text{promo}} \sim \mathcal{N}(0.3, 0.4) \quad (\text{positive prior expectation of promotional lift})$$
$$\beta_{\text{holiday}} \sim \mathcal{N}(0.4, 0.4) \quad (\text{positive prior expectation of holiday volume surge})$$

### 2.3 Fourier Seasonality Representation
Annual cyclicality ($P = 52.1775$ weeks $\approx 365.25$ days) is modeled via $K$ harmonic Fourier terms:

$$S(t) = \sum_{k=1}^K \left[ \gamma_{sk} \sin\left(\frac{2\pi k \cdot \text{DOY}_t}{365.25}\right) + \gamma_{ck} \cos\left(\frac{2\pi k \cdot \text{DOY}_t}{365.25}\right) \right]$$

with Gaussian priors:
$$\gamma_{sk}, \gamma_{ck} \sim \mathcal{N}(0, 0.5), \quad \forall k \in \{1, \dots, K\}$$

### 2.4 Robust Likelihood Hyperpriors
$$\nu \sim \text{Gamma}(\alpha=3.0, \beta=0.2)$$
$$\sigma_{\text{obs}} \sim \text{HalfNormal}(0.5)$$

---

## 3. Posterior Predictive Uncertainty & Credible Intervals

The posterior predictive distribution for future unseen features $\tilde{X}$ is obtained by marginalizing over the parameter posterior $p(\theta \mid \mathcal{D})$:

$$p(\tilde{y} \mid \mathcal{D}, \tilde{X}) = \int p(\tilde{y} \mid \theta, \tilde{X}) \, p(\theta \mid \mathcal{D}) \, d\theta$$

From $S$ draws $\{\theta^{(s)}\}_{s=1}^S$ generated via MCMC/ADVI, we compute:
1. **Median Forecast:** $\hat{y}_t = \text{Median}\left(\{\tilde{y}_t^{(s)}\}_{s=1}^S\right)$
2. **$(1 - \alpha)$ Credible Interval:**
   $$\text{CI}_{1-\alpha} = \left[ Q_{\alpha/2}\left(\{\tilde{y}_t^{(s)}\}\right), \; Q_{1 - \alpha/2}\left(\{\tilde{y}_t^{(s)}\}\right) \right]$$
   Evaluated at $\alpha \in \{0.50, 0.20, 0.05\}$ for the 50% (IQR), 80%, and 95% uncertainty bands.

---

## 4. Inventory Optimization Formulation

### 4.1 Classical Gaussian Inventory Control
Assuming demand during lead time $L$ follows $\mathcal{N}(\mu_{D_L}, \sigma_{D_L}^2)$:
$$\sigma_{D_L} = \sqrt{L \cdot \sigma_D^2 + \mu_D^2 \cdot \sigma_L^2}$$
$$SS_{\text{classical}} = Z_{\alpha} \cdot \sigma_{D_L}$$
$$ROP_{\text{classical}} = \mu_D \cdot L + SS_{\text{classical}}$$

### 4.2 Bayesian Uncertainty-Aware Demand Planning
Rather than forcing a Gaussian assumption, the Bayesian engine constructs lead-time demand by integrating predictive draws over the replenishment horizon $L$:

$$D_L^{(s)} = \sum_{\tau=1}^L \tilde{y}_{t+\tau}^{(s)}, \quad s = 1, \dots, S$$

The exact Reorder Point at target Cycle Service Level $CSL = 1 - \alpha$ is the empirical $(1-\alpha)$-quantile of the simulated lead-time distribution:

$$ROP_{\text{Bayesian}} = \inf \left\{ r \in \mathbb{R} : \frac{1}{S} \sum_{s=1}^S \mathbb{I}\left(D_L^{(s)} \le r\right) \ge 1 - \alpha \right\}$$

$$SS_{\text{Bayesian}} = ROP_{\text{Bayesian}} - \mathbb{E}[D_L]$$

This formulation accounts for:
- Parameter estimation uncertainty (posterior variance of $\beta, \sigma$)
- Positive skewness and asymmetric demand distributions
- Fat-tailed holiday spikes and promotional shocks

### 4.3 Economic Order Quantity (EOQ) & Total Cost Function
$$EOQ = \sqrt{\frac{2 \cdot D_{\text{annual}} \cdot S_{\text{order}}}{H_{\text{annual}}}}$$

$$\text{Total Annual Cost} = \left(\frac{EOQ}{2} + SS\right) \cdot H + \left(\frac{D_{\text{annual}}}{EOQ}\right) \cdot S_{\text{order}} + \mathbb{E}[(D_L - ROP)^+] \cdot \left(\frac{D_{\text{annual}}}{EOQ}\right) \cdot C_{\text{stockout}}$$
