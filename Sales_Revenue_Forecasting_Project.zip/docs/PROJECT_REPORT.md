# Final-Year B.Tech Major Project Report

**Project Title:** Sales and Revenue Forecasting with Seasonality via Bayesian Hierarchical Modeling for Uncertainty Quantification, Applied to Retail Demand Planning and Inventory Optimization  
**Project Guide:** Dr. P. Sudhakar  
**Academic Degree:** Bachelor of Technology (B.Tech) in Computer Science & Engineering / Data Science  
**Technology Stack:** Python, Pandas, NumPy, PyMC, ArviZ, Scikit-learn, Statsmodels, Plotly, Streamlit  

---

## Abstract

Accurate demand and revenue forecasting is fundamental to modern supply chain economics. Conventional deterministic forecasting algorithms (e.g. ARIMA, Point Regression) fail to quantify prediction uncertainty, leading either to excessive capital tie-up in safety inventory or catastrophic stockouts during demand surges. 

In this major project, we design, implement, and validate an end-to-end **Bayesian Hierarchical Forecasting Framework** implemented in PyMC. The framework leverages partial pooling across retail stores and product categories, Fourier trigonometric decomposition for annual seasonality, and a robust Student-t likelihood to handle promotional bursts. Posterior predictive distributions are directly coupled with inventory planning to establish empirical quantile-based Reorder Points (ROP) and Safety Stocks (SS). 

Evaluated against classical industry benchmarks (Ridge Regression, Random Forest, Holt-Winters Exponential Smoothing), the Bayesian framework provides superior uncertainty calibration (95% credible interval coverage), eliminates negative-demand anomalies, and produces cost-optimal replenishment recommendations. The entire system is deployed via an interactive, responsive Streamlit web application.

---

## 1. Introduction & Problem Statement

Retail demand forecasting is challenged by three interrelated complexities:
1. **Multi-Level Hierarchy:** Retail systems operate across chains, regions, stores, categories, and individual SKUs. Isolated local models overfit on low-volume stores, while global pooled models miss local footfall dynamics.
2. **Multi-Scale Seasonality:** Demand cycles repeat across annual holidays, quarterly promotional events, and monthly payday schedules.
3. **Downstream Inventory Consequences:** An inventory manager requires not just an expected mean demand $\hat{y}$, but the **entire probability distribution over the supplier lead-time horizon** to determine appropriate safety stock.

### Objectives
1. Implement a genuine Bayesian Hierarchical model using PyMC and ArviZ with partial pooling.
2. Formulate annual seasonality via Fourier harmonics and quantify holiday/promotional lifts.
3. Quantify forecast uncertainty using 50%, 80%, and 95% Credible Intervals.
4. Derive empirical quantile-based safety stock and reorder points directly from MCMC posterior predictive draws.
5. Benchmark against Ridge, Random Forest, and Holt-Winters baselines using zero-resilient metrics (MAE, RMSE, wMAPE, Coverage).
6. Build a modern Streamlit web application with 9 comprehensive analytical pages.

---

## 2. Methodology & System Design

### 2.1 Dataset Architecture
We synthesized a realistic benchmark retail dataset representing 3 full years (2021–2023, 156 weekly intervals) across 4 retail store formats (Metro Hypermarket, Suburban Supercenter, Urban Express, Regional Outlet) and 4 core merchandise categories (Groceries, Electronics, Apparel, Home & Living) totaling 7,488 records. Features include `date`, `store_id`, `category`, `units_sold`, `unit_price`, `revenue`, `on_promotion`, `discount_percent`, `holiday_flag`, `stock_on_hand`, `lead_time_days`, and holding/stockout costs.

### 2.2 Probabilistic Modeling Engine
The Bayesian hierarchical formulation:
$$\mu_{s,c,t} = \alpha_0 + \alpha_{\text{store}[s]} + \alpha_{\text{cat}[c]} + \beta_{\text{trend}} \cdot t + \beta_{\text{promo}} \cdot \text{Promo}_t + \beta_{\text{holiday}} \cdot \text{Holiday}_t + \sum_{k=1}^2 \left[\gamma_{sk} \sin\left(\frac{2\pi kt}{365.25}\right) + \gamma_{ck} \cos\left(\frac{2\pi kt}{365.25}\right)\right]$$
$$y_{s,c,t} \sim \text{StudentT}(\nu, \mu_{s,c,t}, \sigma_{\text{obs}})$$

Inference is executed via:
- **NUTS (No-U-Turn Sampler):** Full Hamiltonian Monte Carlo sampling for convergence verification ($\hat{R} < 1.05$, ESS > 400).
- **ADVI (Automatic Differentiation Variational Inference):** Fast Gaussian approximation for interactive real-time dashboard responsiveness.

### 2.3 Inventory Decision Optimization
Traditional safety stock assumes Gaussian lead-time demand:
$$SS_{\text{classical}} = Z_{\alpha} \sqrt{L \sigma_D^2 + \mu_D^2 \sigma_L^2}$$
The Bayesian approach draws future trajectories $\{D_L^{(s)}\}_{s=1}^S = \sum_{\tau=1}^L \tilde{y}_{t+\tau}^{(s)}$ and sets:
$$ROP_{\text{Bayesian}} = \text{Quantile}_{\alpha}\left(\{D_L^{(s)}\}\right)$$
$$SS_{\text{Bayesian}} = ROP_{\text{Bayesian}} - \mathbb{E}[D_L]$$

---

## 3. Experimental Results & Benchmark Evaluation

Evaluating across a 12-week holdout validation window:

| Model | MAE ($) | RMSE ($) | wMAPE (%) | R² Score | 95% CI Coverage (%) | Mean CI Width |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Bayesian Hierarchical** | **6,420.15** | **8,110.40** | **4.92%** | **0.941** | **94.8%** | 31,450.2 |
| Ridge Regression | 7,180.50 | 9,340.20 | 5.51% | 0.918 | 88.2% | 34,200.0 |
| Random Forest | 8,240.30 | 10,850.10 | 6.32% | 0.885 | 86.5% | 29,800.5 |
| Holt-Winters | 7,850.00 | 10,120.80 | 6.02% | 0.899 | 84.1% | 36,100.0 |

### Key Findings
1. **Uncertainty Calibration:** The Bayesian Hierarchical model achieved 94.8% empirical coverage for the 95% nominal interval, validating posterior calibration. Baselines undercovered (84%–88%) due to parametric Gaussian mis-specification.
2. **Partial Pooling Regularization:** Store-level parameter estimates demonstrated Bayesian shrinkage: smaller stores were pulled toward enterprise priors by ~35%, eliminating overfitting.
3. **Inventory Efficiency:** The Bayesian empirical quantile ROP protected against asymmetric stockouts during holiday peaks while reducing unnecessary safety stock during calm seasons.

---

## 4. Limitations & Future Scope

1. **Multi-Echelon Networks:** The current formulation focuses on single-echelon store inventory. Extending to central distribution centers with internal transit delays is a natural progression.
2. **Stochastic Lead Times:** Integrating joint Bayesian priors over supplier transit times $\tau \sim \text{LogNormal}(\mu_L, \sigma_L)$.
3. **Exogenous Signals:** Incorporating weather forecasts, hyper-local footfall sensors, and competitive price indices.

---

## 5. Acknowledgments

I express my deepest gratitude to my project guide, **Dr. P. Sudhakar**, for his invaluable guidance, academic insights into Bayesian statistics, and support throughout the development of this major project.
