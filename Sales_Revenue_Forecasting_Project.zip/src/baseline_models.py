"""
baseline_models.py
==================
Classical and Machine Learning Baseline Forecasting Models for benchmark comparison:
  1. Ridge Regression (L2 regularized linear model with Fourier features)
  2. Random Forest Regressor (Nonlinear ensemble baseline)
  3. Holt-Winters Exponential Smoothing / Seasonal Naive (Classical statistical benchmark)
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import RandomForestRegressor
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from typing import Dict, Any, Tuple, Optional, List
import warnings
warnings.filterwarnings("ignore")

class RidgeBaselineForecaster:
    """Ridge regression baseline with cross-validated regularization."""
    def __init__(self, target_col: str = "revenue"):
        self.target_col = target_col
        self.model = RidgeCV(alphas=np.logspace(-3, 3, 20), cv=3)
        self.feature_cols: List[str] = []
        self.train_residuals: np.ndarray = np.array([])
        
    def _get_feature_cols(self, df: pd.DataFrame) -> List[str]:
        candidates = [
            "trend_t", "on_promotion", "holiday_flag",
            "fourier_sin_1", "fourier_cos_1", "fourier_sin_2", "fourier_cos_2",
            "lag_1", "lag_2", "lag_4", "rolling_mean_4"
        ]
        return [c for c in candidates if c in df.columns]

    def fit(self, train_df: pd.DataFrame):
        self.feature_cols = self._get_feature_cols(train_df)
        X = train_df[self.feature_cols].values
        y = train_df[self.target_col].values
        self.model.fit(X, y)
        train_preds = self.model.predict(X)
        self.train_residuals = y - train_preds
        return self

    def predict(self, test_df: pd.DataFrame) -> pd.DataFrame:
        X = test_df[self.feature_cols].values
        preds = np.maximum(0.0, self.model.predict(X))
        res = test_df.copy()
        res["y_pred_mean"] = preds
        res["y_pred_median"] = preds
        # Parametric uncertainty via residual standard error
        sigma_res = np.std(self.train_residuals) if len(self.train_residuals) > 0 else 1.0
        res["ci_lower_80"] = np.maximum(0.0, preds - 1.28 * sigma_res)
        res["ci_upper_80"] = preds + 1.28 * sigma_res
        res["ci_lower_95"] = np.maximum(0.0, preds - 1.96 * sigma_res)
        res["ci_upper_95"] = preds + 1.96 * sigma_res
        return res


class RandomForestBaselineForecaster:
    """Random Forest Regressor baseline capturing non-linear interactions."""
    def __init__(self, target_col: str = "revenue", n_estimators: int = 100, random_state: int = 42):
        self.target_col = target_col
        self.model = RandomForestRegressor(n_estimators=n_estimators, max_depth=8, random_state=random_state, n_jobs=-1)
        self.feature_cols: List[str] = []
        self.train_residuals: np.ndarray = np.array([])

    def _get_feature_cols(self, df: pd.DataFrame) -> List[str]:
        candidates = [
            "trend_t", "month", "quarter", "week_of_year", "on_promotion", "holiday_flag",
            "fourier_sin_1", "fourier_cos_1", "fourier_sin_2", "fourier_cos_2",
            "lag_1", "lag_2", "lag_4", "rolling_mean_4"
        ]
        return [c for c in candidates if c in df.columns]

    def fit(self, train_df: pd.DataFrame):
        self.feature_cols = self._get_feature_cols(train_df)
        X = train_df[self.feature_cols].values
        y = train_df[self.target_col].values
        self.model.fit(X, y)
        train_preds = self.model.predict(X)
        self.train_residuals = y - train_preds
        return self

    def predict(self, test_df: pd.DataFrame) -> pd.DataFrame:
        X = test_df[self.feature_cols].values
        preds = np.maximum(0.0, self.model.predict(X))
        res = test_df.copy()
        res["y_pred_mean"] = preds
        res["y_pred_median"] = preds
        # Empirical quantile bounds from tree ensemble variance
        tree_preds = np.array([tree.predict(X) for tree in self.model.estimators_])
        res["ci_lower_80"] = np.maximum(0.0, np.quantile(tree_preds, 0.10, axis=0))
        res["ci_upper_80"] = np.quantile(tree_preds, 0.90, axis=0)
        res["ci_lower_95"] = np.maximum(0.0, np.quantile(tree_preds, 0.025, axis=0))
        res["ci_upper_95"] = np.quantile(tree_preds, 0.975, axis=0)
        return res


class HoltWintersBaselineForecaster:
    """Holt-Winters Triple Exponential Smoothing baseline."""
    def __init__(self, target_col: str = "revenue", seasonal_periods: int = 52):
        self.target_col = target_col
        self.seasonal_periods = seasonal_periods
        self.fitted_model = None

    def fit(self, train_df: pd.DataFrame):
        series = train_df[self.target_col].values.astype(float)
        # Ensure strictly positive series for additive model
        series_clean = np.maximum(series, 1.0)
        n = len(series_clean)
        
        # If series is shorter than 2 seasons, fallback to simple double exponential
        if n >= 2 * self.seasonal_periods:
            hw = ExponentialSmoothing(
                series_clean,
                trend="add",
                seasonal="add",
                seasonal_periods=self.seasonal_periods,
                initialization_method="estimated"
            )
        else:
            hw = ExponentialSmoothing(
                series_clean,
                trend="add",
                seasonal=None,
                initialization_method="estimated"
            )
        self.fitted_model = hw.fit()
        return self

    def predict(self, test_df: pd.DataFrame) -> pd.DataFrame:
        steps = len(test_df)
        preds = np.maximum(0.0, self.fitted_model.forecast(steps))
        res = test_df.copy()
        res["y_pred_mean"] = preds
        res["y_pred_median"] = preds
        
        residuals = self.fitted_model.resid
        sigma = np.std(residuals) if len(residuals) > 0 else 1.0
        # Uncertainty grows with horizon step h
        h = np.sqrt(np.arange(1, steps + 1))
        res["ci_lower_80"] = np.maximum(0.0, preds - 1.28 * sigma * h)
        res["ci_upper_80"] = preds + 1.28 * sigma * h
        res["ci_lower_95"] = np.maximum(0.0, preds - 1.96 * sigma * h)
        res["ci_upper_95"] = preds + 1.96 * sigma * h
        return res
