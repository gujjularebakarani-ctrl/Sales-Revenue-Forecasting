"""
bayesian_model.py
=================
Genuine Bayesian Hierarchical Forecasting Model using PyMC and ArviZ.
Implements partial pooling across retail stores & categories, continuous trend,
Fourier annual seasonality harmonics, promotional/holiday interventions,
and robust Student-t likelihood for uncertainty quantification.
"""

import numpy as np
import pandas as pd
import pymc as pm
import arviz as az
from typing import Dict, Any, Tuple, Optional, List
import warnings
warnings.filterwarnings("ignore")

class BayesianHierarchicalForecaster:
    """
    Bayesian Hierarchical Forecasting Engine.
    
    Mathematical Formulation:
      y_{s,c,t} ~ StudentT(nu, mu_{s,c,t}, sigma_obs)
      
      mu_{s,c,t} = alpha_0 + alpha_{store}[s] + alpha_{cat}[c]
                 + beta_trend * trend_t
                 + beta_promo * on_promo
                 + beta_holiday * holiday_flag
                 + sum_k (gamma_{sin,k} * sin_k(t) + gamma_{cos,k} * cos_k(t))
                 
      Hierarchical Priors (Partial Pooling / Shrinkage):
        alpha_0 ~ Normal(mu_y, 2 * sigma_y)
        sigma_store ~ HalfNormal(sigma_y * 0.5)
        alpha_{store}[s] ~ Normal(0, sigma_store)
        sigma_cat ~ HalfNormal(sigma_y * 0.5)
        alpha_{cat}[c] ~ Normal(0, sigma_cat)
        beta_trend ~ Normal(0, sigma_y * 0.5)
        beta_promo ~ Normal(0.2 * sigma_y, sigma_y * 0.5)
        beta_holiday ~ Normal(0.3 * sigma_y, sigma_y * 0.5)
        gamma_{sin,k}, gamma_{cos,k} ~ Normal(0, sigma_y * 0.5)
        nu ~ Gamma(alpha=2, beta=0.1)  [degrees of freedom]
        sigma_obs ~ HalfNormal(sigma_y)
    """

    def __init__(
        self,
        fourier_harmonics: int = 2,
        target_col: str = "revenue",
        inference_method: str = "nuts",  # 'nuts' or 'advi'
        draws: int = 600,
        tune: int = 600,
        chains: int = 2,
        random_seed: int = 42
    ):
        self.fourier_harmonics = fourier_harmonics
        self.target_col = target_col
        self.inference_method = inference_method
        self.draws = draws
        self.tune = tune
        self.chains = chains
        self.random_seed = random_seed
        
        # State
        self.model: Optional[pm.Model] = None
        self.idata: Optional[az.InferenceData] = None
        self.train_data: Optional[pd.DataFrame] = None
        self.store_mapping: Dict[str, int] = {}
        self.cat_mapping: Dict[str, int] = {}
        self.y_scaler_mean: float = 0.0
        self.y_scaler_std: float = 1.0
        self.is_hierarchical: bool = False

    def _prepare_design_matrices(self, df: pd.DataFrame, is_train: bool = True) -> Dict[str, np.ndarray]:
        """Extract and standardize predictors and target variables."""
        n_obs = len(df)
        
        # Target
        y_raw = df[self.target_col].values.astype(float) if self.target_col in df.columns else np.zeros(n_obs)
        if is_train:
            self.y_scaler_mean = float(np.mean(y_raw))
            self.y_scaler_std = float(np.std(y_raw)) if np.std(y_raw) > 1e-6 else 1.0
            
        y_scaled = (y_raw - self.y_scaler_mean) / self.y_scaler_std
        
        # Trend
        if "trend_t" in df.columns:
            trend = df["trend_t"].values.astype(float)
        else:
            trend = np.linspace(0, n_obs / 52.14, n_obs)
            
        # Fourier terms
        sin_terms = []
        cos_terms = []
        for k in range(1, self.fourier_harmonics + 1):
            sin_col = f"fourier_sin_{k}"
            cos_col = f"fourier_cos_{k}"
            if sin_col in df.columns and cos_col in df.columns:
                sin_terms.append(df[sin_col].values.astype(float))
                cos_terms.append(df[cos_col].values.astype(float))
            else:
                day_of_year = pd.to_datetime(df["date"]).dt.dayofyear.values
                sin_terms.append(np.sin(2 * np.pi * k * day_of_year / 365.25))
                cos_terms.append(np.cos(2 * np.pi * k * day_of_year / 365.25))
                
        sin_mat = np.column_stack(sin_terms) if sin_terms else np.zeros((n_obs, 1))
        cos_mat = np.column_stack(cos_terms) if cos_terms else np.zeros((n_obs, 1))
        
        # Binary flags
        promo = df["on_promotion"].values.astype(float) if "on_promotion" in df.columns else np.zeros(n_obs)
        holiday = df["holiday_flag"].values.astype(float) if "holiday_flag" in df.columns else np.zeros(n_obs)
        
        # Hierarchical indices
        store_idx = np.zeros(n_obs, dtype=int)
        cat_idx = np.zeros(n_obs, dtype=int)
        
        if "store_id" in df.columns:
            if is_train:
                stores = sorted(df["store_id"].unique())
                self.store_mapping = {s: i for i, s in enumerate(stores)}
            store_idx = df["store_id"].map(self.store_mapping).fillna(0).values.astype(int)
            
        if "category" in df.columns:
            if is_train:
                cats = sorted(df["category"].unique())
                self.cat_mapping = {c: i for i, c in enumerate(cats)}
            cat_idx = df["category"].map(self.cat_mapping).fillna(0).values.astype(int)
            
        return {
            "y": y_scaled,
            "y_raw": y_raw,
            "trend": trend,
            "sin_mat": sin_mat,
            "cos_mat": cos_mat,
            "promo": promo,
            "holiday": holiday,
            "store_idx": store_idx,
            "cat_idx": cat_idx,
            "n_stores": max(len(self.store_mapping), 1),
            "n_cats": max(len(self.cat_mapping), 1),
            "n_harmonics": self.fourier_harmonics
        }

    def build_model(self, train_df: pd.DataFrame) -> pm.Model:
        """Construct the PyMC Hierarchical Bayesian model."""
        self.train_data = train_df.copy()
        self.is_hierarchical = ("store_id" in train_df.columns and len(train_df["store_id"].unique()) > 1) or \
                               ("category" in train_df.columns and len(train_df["category"].unique()) > 1)
                               
        matrices = self._prepare_design_matrices(train_df, is_train=True)
        
        with pm.Model() as model:
            # Mutable data containers for out-of-sample predictions
            t_data = pm.Data("t_data", matrices["trend"])
            promo_data = pm.Data("promo_data", matrices["promo"])
            holiday_data = pm.Data("holiday_data", matrices["holiday"])
            sin_data = pm.Data("sin_data", matrices["sin_mat"])
            cos_data = pm.Data("cos_data", matrices["cos_mat"])
            
            # Priors on global intercept & trend
            alpha_0 = pm.Normal("alpha_0", mu=0.0, sigma=1.0)
            beta_trend = pm.Normal("beta_trend", mu=0.0, sigma=0.5)
            beta_promo = pm.Normal("beta_promo", mu=0.3, sigma=0.4)
            beta_holiday = pm.Normal("beta_holiday", mu=0.4, sigma=0.4)
            
            # Fourier Seasonality Coefficients
            gamma_sin = pm.Normal("gamma_sin", mu=0.0, sigma=0.5, shape=matrices["n_harmonics"])
            gamma_cos = pm.Normal("gamma_cos", mu=0.0, sigma=0.5, shape=matrices["n_harmonics"])
            seasonality = pm.math.dot(sin_data, gamma_sin) + pm.math.dot(cos_data, gamma_cos)
            
            # Base linear predictor
            mu = alpha_0 + beta_trend * t_data + beta_promo * promo_data + beta_holiday * holiday_data + seasonality
            
            if self.is_hierarchical:
                s_idx = pm.Data("store_idx", matrices["store_idx"])
                c_idx = pm.Data("cat_idx", matrices["cat_idx"])
                
                # Store-level random intercepts with hyperpriors (shrinkage)
                sigma_store = pm.HalfNormal("sigma_store", sigma=0.5)
                alpha_store = pm.Normal("alpha_store", mu=0.0, sigma=sigma_store, shape=matrices["n_stores"])
                
                # Category-level random intercepts with hyperpriors
                sigma_cat = pm.HalfNormal("sigma_cat", sigma=0.5)
                alpha_cat = pm.Normal("alpha_cat", mu=0.0, sigma=sigma_cat, shape=matrices["n_cats"])
                
                mu = mu + alpha_store[s_idx] + alpha_cat[c_idx]
                
            # Likelihood with robust Student-t distribution (heavier tails for sales promotions)
            nu = pm.Gamma("nu", alpha=3.0, beta=0.2)
            sigma_obs = pm.HalfNormal("sigma_obs", sigma=0.5)
            
            y_obs = pm.StudentT("y_obs", nu=nu, mu=mu, sigma=sigma_obs, observed=matrices["y"])
            
        self.model = model
        return model

    def fit(self, train_df: pd.DataFrame, verbose: bool = False) -> az.InferenceData:
        """Fit the Bayesian model using NUTS MCMC or ADVI."""
        self.build_model(train_df)
        
        with self.model:
            if self.inference_method.lower() == "nuts":
                # NUTS Sampling
                self.idata = pm.sample(
                    draws=self.draws,
                    tune=self.tune,
                    chains=self.chains,
                    cores=1,  # Windows stability
                    random_seed=self.random_seed,
                    progressbar=verbose,
                    return_inferencedata=True
                )
            elif self.inference_method.lower() == "advi":
                # Fast Variational Inference
                approx = pm.fit(
                    n=15000,
                    method="advi",
                    random_seed=self.random_seed,
                    progressbar=verbose
                )
                self.idata = approx.sample(draws=self.draws * self.chains)
            else:
                raise ValueError(f"Unknown inference method: {self.inference_method}")
                
            # Sample posterior predictive on training data
            post_pred = pm.sample_posterior_predictive(
                self.idata,
                random_seed=self.random_seed,
                progressbar=verbose
            )
            if hasattr(self.idata, "extend"):
                try:
                    self.idata.extend(post_pred)
                except Exception:
                    pass
            elif hasattr(self.idata, "__setitem__") and "posterior_predictive" in post_pred:
                try:
                    self.idata["posterior_predictive"] = post_pred["posterior_predictive"]
                except Exception:
                    pass
            self.post_pred = post_pred
            
        return self.idata

    def predict(
        self,
        future_df: pd.DataFrame,
        credible_levels: List[float] = [0.50, 0.80, 0.95]
    ) -> pd.DataFrame:
        """
        Generate posterior predictive forecasts and credible intervals for out-of-sample data.
        """
        if self.model is None or self.idata is None:
            raise RuntimeError("Model has not been fitted yet. Call .fit() first.")
            
        matrices = self._prepare_design_matrices(future_df, is_train=False)
        
        post = self.idata.posterior
        # Flatten chain and draw dimensions
        alpha_0 = post["alpha_0"].values.flatten()
        beta_trend = post["beta_trend"].values.flatten()
        beta_promo = post["beta_promo"].values.flatten()
        beta_holiday = post["beta_holiday"].values.flatten()
        gamma_sin = post["gamma_sin"].values.reshape(-1, self.fourier_harmonics)
        gamma_cos = post["gamma_cos"].values.reshape(-1, self.fourier_harmonics)
        sigma_obs = post["sigma_obs"].values.flatten()
        nu = post["nu"].values.flatten() if "nu" in post else np.full_like(sigma_obs, 30.0)
        
        n_samples = len(alpha_0)
        n_obs = len(future_df)
        
        # Base mu: shape (n_samples, n_obs)
        mu_samples = alpha_0[:, None] + beta_trend[:, None] * matrices["trend"][None, :]
        mu_samples += beta_promo[:, None] * matrices["promo"][None, :]
        mu_samples += beta_holiday[:, None] * matrices["holiday"][None, :]
        
        # Seasonality via matrix multiplication
        season_sin = np.dot(gamma_sin, matrices["sin_mat"].T)
        season_cos = np.dot(gamma_cos, matrices["cos_mat"].T)
        mu_samples += season_sin + season_cos
        
        if self.is_hierarchical and "alpha_store" in post and "alpha_cat" in post:
            alpha_store = post["alpha_store"].values.reshape(n_samples, -1)
            alpha_cat = post["alpha_cat"].values.reshape(n_samples, -1)
            mu_samples += alpha_store[:, matrices["store_idx"]]
            mu_samples += alpha_cat[:, matrices["cat_idx"]]
            
        # Draw from Student-t predictive distribution
        np.random.seed(self.random_seed)
        noise = np.random.standard_t(df=np.maximum(nu[:, None], 2.1), size=(n_samples, n_obs)) * sigma_obs[:, None]
        pred_scaled_2d = mu_samples + noise
        
        # Unscale back to raw units
        pred_raw = pred_scaled_2d * self.y_scaler_std + self.y_scaler_mean
        pred_raw = np.maximum(0.0, pred_raw)  # Sales/Revenue non-negative
        
        res = future_df.copy()
        res["y_pred_mean"] = np.mean(pred_raw, axis=0)
        res["y_pred_median"] = np.median(pred_raw, axis=0)
        res["y_pred_std"] = np.std(pred_raw, axis=0)
        
        # Quantile credible intervals
        for level in sorted(credible_levels):
            alpha = (1.0 - level) / 2.0
            lower_q = alpha
            upper_q = 1.0 - alpha
            pct_int = int(round(level * 100))
            res[f"ci_lower_{pct_int}"] = np.quantile(pred_raw, lower_q, axis=0)
            res[f"ci_upper_{pct_int}"] = np.quantile(pred_raw, upper_q, axis=0)
            
        # Store predictive samples matrix for downstream inventory simulation
        self._last_pred_samples = pred_raw
        return res

    def get_predictive_samples(self) -> Optional[np.ndarray]:
        """Return the raw Monte Carlo sample matrix from the last predict call."""
        return getattr(self, "_last_pred_samples", None)

    def get_diagnostics(self) -> Dict[str, Any]:
        """Compute Gelman-Rubin R-hat and Effective Sample Size (ESS) metrics."""
        if self.idata is None or "posterior" not in self.idata:
            return {}
            
        summary = az.summary(self.idata, var_names=["alpha_0", "beta_trend", "beta_promo", "beta_holiday", "sigma_obs"])
        
        # Check if r_hat has valid non-NaN values (requires multi-chain MCMC)
        rhat_clean = summary["r_hat"].dropna() if "r_hat" in summary.columns else pd.Series(dtype=float)
        max_rhat = float(rhat_clean.max()) if not rhat_clean.empty else None
        
        ess_b_clean = summary["ess_bulk"].dropna() if "ess_bulk" in summary.columns else pd.Series(dtype=float)
        min_ess_bulk = float(ess_b_clean.min()) if not ess_b_clean.empty else None
        
        ess_t_clean = summary["ess_tail"].dropna() if "ess_tail" in summary.columns else pd.Series(dtype=float)
        min_ess_tail = float(ess_t_clean.min()) if not ess_t_clean.empty else None

        return {
            "summary_df": summary,
            "max_rhat": max_rhat,
            "min_ess_bulk": min_ess_bulk,
            "min_ess_tail": min_ess_tail,
            "inference_method": self.inference_method
        }

    def get_hierarchical_shrinkage_summary(self) -> Optional[pd.DataFrame]:
        """Extract store-level and category-level parameter estimates to demonstrate Bayesian shrinkage."""
        if not self.is_hierarchical or self.idata is None:
            return None
            
        records = []
        post = self.idata.posterior
        
        if "alpha_store" in post:
            store_means = post["alpha_store"].mean(dim=["chain", "draw"]).values
            store_stds = post["alpha_store"].std(dim=["chain", "draw"]).values
            for store_name, idx in self.store_mapping.items():
                records.append({
                    "Level": "Store",
                    "Entity": store_name,
                    "Shrinkage_Offset": float(store_means[idx]),
                    "Uncertainty_Std": float(store_stds[idx])
                })
                
        if "alpha_cat" in post:
            cat_means = post["alpha_cat"].mean(dim=["chain", "draw"]).values
            cat_stds = post["alpha_cat"].std(dim=["chain", "draw"]).values
            for cat_name, idx in self.cat_mapping.items():
                records.append({
                    "Level": "Category",
                    "Entity": cat_name,
                    "Shrinkage_Offset": float(cat_means[idx]),
                    "Uncertainty_Std": float(cat_stds[idx])
                })
                
        return pd.DataFrame(records)
