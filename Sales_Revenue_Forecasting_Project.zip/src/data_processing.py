"""
data_processing.py
==================
Comprehensive data cleaning, validation, preprocessing, feature engineering,
and aggregation pipeline for Retail Sales & Revenue Forecasting.
"""

import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any, Optional, List
import io

REQUIRED_COLUMNS = [
    "date", "store_id", "category", "units_sold", "revenue"
]

def format_date(dt_val: Any) -> str:
    """
    Format any date-like object (pd.Timestamp, datetime.date, datetime.datetime, str)
    to a standardized 'YYYY-MM-DD' string safely without subscripting errors.
    """
    if pd.isna(dt_val):
        return "N/A"
    try:
        return pd.to_datetime(dt_val).strftime("%Y-%m-%d")
    except Exception:
        return str(dt_val)[:10]

def load_and_validate_data(source: Any) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Load data from a CSV file path, buffer, or DataFrame, validate its schema,
    clean missing values, and return the cleaned DataFrame alongside validation report.
    """
    report = {
        "is_valid": True,
        "errors": [],
        "warnings": [],
        "initial_rows": 0,
        "clean_rows": 0,
        "missing_values_handled": 0,
        "date_range": None
    }
    
    try:
        if isinstance(source, pd.DataFrame):
            df = source.copy()
        elif isinstance(source, (str, io.BytesIO, io.StringIO)):
            df = pd.read_csv(source)
        else:
            raise ValueError(f"Unsupported data source type: {type(source)}")
    except Exception as e:
        report["is_valid"] = False
        report["errors"].append(f"Failed to read CSV source: {str(e)}")
        return pd.DataFrame(), report
        
    report["initial_rows"] = len(df)
    
    # Check required columns (case-insensitive mapping)
    col_mapping = {c.lower(): c for c in df.columns}
    missing_req = [col for col in REQUIRED_COLUMNS if col.lower() not in col_mapping]
    if missing_req:
        report["is_valid"] = False
        report["errors"].append(f"Missing required columns: {missing_req}")
        return df, report
        
    # Standardize column names
    df = df.rename(columns={col_mapping[c.lower()]: c.lower() for c in REQUIRED_COLUMNS})
    
    # Date parsing
    try:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        null_dates = df["date"].isna().sum()
        if null_dates > 0:
            report["warnings"].append(f"Dropped {null_dates} rows with invalid dates.")
            report["missing_values_handled"] += int(null_dates)
            df = df.dropna(subset=["date"])
    except Exception as e:
        report["is_valid"] = False
        report["errors"].append(f"Failed to parse 'date' column: {str(e)}")
        return df, report

    # Numeric conversions and handling
    numeric_cols = ["units_sold", "revenue"]
    for col in ["unit_price", "discount_percent", "lead_time_days", "holding_cost_per_unit", "stockout_cost_per_unit"]:
        if col in df.columns:
            numeric_cols.append(col)
            
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            null_count = df[col].isna().sum()
            if null_count > 0:
                # Forward fill then median fill for safety
                df[col] = df[col].ffill().bfill().fillna(0.0)
                report["missing_values_handled"] += int(null_count)
                report["warnings"].append(f"Imputed {null_count} missing values in '{col}'.")
                
    # Sort chronologically
    df = df.sort_values("date").reset_index(drop=True)
    
    # Defaults for optional columns if not present
    if "on_promotion" not in df.columns:
        df["on_promotion"] = 0
    else:
        df["on_promotion"] = df["on_promotion"].fillna(0).astype(int)
        
    if "holiday_flag" not in df.columns:
        df["holiday_flag"] = 0
    else:
        df["holiday_flag"] = df["holiday_flag"].fillna(0).astype(int)
        
    if "store_name" not in df.columns:
        df["store_name"] = df["store_id"].astype(str)
        
    if "unit_price" not in df.columns:
        # Avoid division by zero
        df["unit_price"] = np.where(df["units_sold"] > 0, df["revenue"] / np.maximum(df["units_sold"], 1), 10.0)
        
    if "lead_time_days" not in df.columns:
        df["lead_time_days"] = 14
    if "holding_cost_per_unit" not in df.columns:
        df["holding_cost_per_unit"] = 1.00
    if "stockout_cost_per_unit" not in df.columns:
        df["stockout_cost_per_unit"] = 15.00
        
    report["clean_rows"] = len(df)
    if len(df) > 0:
        report["date_range"] = (format_date(df["date"].min()), format_date(df["date"].max()))
        
    return df, report


def aggregate_sales_data(
    df: pd.DataFrame,
    freq: str = "W-MON",
    group_by: Optional[List[str]] = None,
    target_metric: str = "revenue"
) -> pd.DataFrame:
    """
    Aggregate transactional or fine-grained sales data to regular time series
    for hierarchical forecasting.
    
    Parameters:
      df: Cleaned sales dataframe
      freq: Frequency for resampling ('W-MON' for weekly, 'M' for monthly)
      group_by: Hierarchy levels, e.g. ['store_id', 'category'] or None for overall total
      target_metric: 'revenue' or 'units_sold'
    """
    df_work = df.copy()
    
    if group_by:
        # Group by hierarchy and resample by date
        agg_dict = {
            "units_sold": "sum",
            "revenue": "sum",
            "on_promotion": "max",
            "holiday_flag": "max",
            "unit_price": "mean",
            "lead_time_days": "mean",
            "holding_cost_per_unit": "mean",
            "stockout_cost_per_unit": "mean"
        }
        
        # Include store_name / product_name if in grouping or metadata
        if "store_name" in df_work.columns and "store_id" in group_by:
            agg_dict["store_name"] = "first"
            
        grouped = (
            df_work.groupby(group_by + [pd.Grouper(key="date", freq=freq)])
            .agg({k: v for k, v in agg_dict.items() if k in df_work.columns})
            .reset_index()
            .sort_values("date")
        )
        return grouped
    else:
        # Total enterprise aggregation
        agg_dict = {
            "units_sold": "sum",
            "revenue": "sum",
            "on_promotion": "max",
            "holiday_flag": "max",
            "unit_price": "mean",
            "lead_time_days": "mean",
            "holding_cost_per_unit": "mean",
            "stockout_cost_per_unit": "mean"
        }
        resampled = (
            df_work.groupby(pd.Grouper(key="date", freq=freq))
            .agg({k: v for k, v in agg_dict.items() if k in df_work.columns})
            .reset_index()
            .sort_values("date")
        )
        return resampled


def engineer_forecasting_features(
    df: pd.DataFrame,
    fourier_harmonics: int = 2,
    target_col: str = "revenue",
    lags: List[int] = [1, 2, 4, 12]
) -> pd.DataFrame:
    """
    Build rich predictive features for both Bayesian and baseline models:
    - Time trend
    - Annual and semi-annual Fourier seasonality terms (sine & cosine)
    - Calendar features (month, quarter, week of year)
    - Autoregressive lags & rolling moving averages
    """
    feat_df = df.copy()
    feat_df["date"] = pd.to_datetime(feat_df["date"])
    feat_df = feat_df.sort_values("date").reset_index(drop=True)
    
    # Continuous normalized time index
    min_date = feat_df["date"].min()
    feat_df["time_days"] = (feat_df["date"] - min_date).dt.days
    feat_df["trend_t"] = feat_df["time_days"] / 365.25  # In years
    
    # Calendar features
    feat_df["year"] = feat_df["date"].dt.year
    feat_df["month"] = feat_df["date"].dt.month
    feat_df["quarter"] = feat_df["date"].dt.quarter
    feat_df["week_of_year"] = feat_df["date"].dt.isocalendar().week.astype(int)
    
    # Fourier harmonics for annual seasonality (Period P ~ 52.1775 weeks or 365.25 days)
    # Using day of year for smooth periodic continuity
    day_of_year = feat_df["date"].dt.dayofyear
    for k in range(1, fourier_harmonics + 1):
        feat_df[f"fourier_sin_{k}"] = np.sin(2 * np.pi * k * day_of_year / 365.25)
        feat_df[f"fourier_cos_{k}"] = np.cos(2 * np.pi * k * day_of_year / 365.25)
        
    # Lags and rolling stats if single series
    if "store_id" not in feat_df.columns:
        for lag in lags:
            feat_df[f"lag_{lag}"] = feat_df[target_col].shift(lag)
        feat_df["rolling_mean_4"] = feat_df[target_col].shift(1).rolling(4, min_periods=1).mean()
        feat_df["rolling_std_4"] = feat_df[target_col].shift(1).rolling(4, min_periods=1).std().fillna(0)
    else:
        # Grouped lags per store/category
        group_keys = [c for c in ["store_id", "category"] if c in feat_df.columns]
        for lag in lags:
            feat_df[f"lag_{lag}"] = feat_df.groupby(group_keys)[target_col].shift(lag)
        feat_df["rolling_mean_4"] = feat_df.groupby(group_keys)[target_col].shift(1).transform(lambda s: s.rolling(4, min_periods=1).mean())
        feat_df["rolling_std_4"] = feat_df.groupby(group_keys)[target_col].shift(1).transform(lambda s: s.rolling(4, min_periods=1).std()).fillna(0)
        
    # Impute initial lags with backfill
    for col in feat_df.columns:
        if col.startswith("lag_") or col.startswith("rolling_"):
            feat_df[col] = feat_df[col].bfill().fillna(0)
            
    return feat_df


def split_train_test(
    df: pd.DataFrame,
    test_periods: int = 12
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Split time series data chronologically into train and holdout test sets.
    test_periods: Number of most recent periods (e.g. 12 weeks) to hold out.
    """
    unique_dates = sorted(df["date"].unique())
    if len(unique_dates) <= test_periods:
        raise ValueError(f"Total time periods ({len(unique_dates)}) is <= test_periods ({test_periods})")
        
    split_date = unique_dates[-test_periods]
    train_df = df[df["date"] < split_date].copy().reset_index(drop=True)
    test_df = df[df["date"] >= split_date].copy().reset_index(drop=True)
    
    return train_df, test_df
