"""
evaluation.py
=============
Model Evaluation and Forecast Quality Metrics:
  - Mean Absolute Error (MAE)
  - Root Mean Squared Error (RMSE)
  - Mean Absolute Percentage Error (MAPE) with robust zero handling
  - Weighted Mean Absolute Percentage Error (wMAPE)
  - Coefficient of Determination (R-squared)
  - Bayesian Credible Interval Empirical Coverage (80% and 95% CI)
  - Interval Score (Winkler Score for sharpness and calibration)
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple, Optional, List

def compute_forecast_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_lower_80: Optional[np.ndarray] = None,
    y_upper_80: Optional[np.ndarray] = None,
    y_lower_95: Optional[np.ndarray] = None,
    y_upper_95: Optional[np.ndarray] = None,
    epsilon: float = 1e-4
) -> Dict[str, float]:
    """
    Compute point accuracy and Bayesian uncertainty calibration metrics.
    Handles zero actual values gracefully with wMAPE and epsilon-adjusted MAPE.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    
    n = len(y_true)
    if n == 0:
        return {}
        
    residuals = y_true - y_pred
    
    # 1. Mean Absolute Error
    mae = float(np.mean(np.abs(residuals)))
    
    # 2. Root Mean Squared Error
    rmse = float(np.sqrt(np.mean(residuals ** 2)))
    
    # 3. Weighted MAPE (Supply chain standard: Sum(|e|) / Sum(y))
    sum_y = np.sum(np.abs(y_true))
    wmape = float((np.sum(np.abs(residuals)) / (sum_y + epsilon)) * 100.0)
    
    # 4. Epsilon-adjusted MAPE
    mape = float(np.mean(np.abs(residuals) / (np.abs(y_true) + epsilon)) * 100.0)
    
    # 5. Non-zero MAPE (Strictly for positive actual sales)
    pos_mask = y_true > 0
    if np.sum(pos_mask) > 0:
        mape_positive_only = float(np.mean(np.abs(residuals[pos_mask]) / y_true[pos_mask]) * 100.0)
    else:
        mape_positive_only = 0.0
        
    # 6. R-squared
    ss_res = np.sum(residuals ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    r2 = float(1.0 - (ss_res / (ss_tot + 1e-6))) if ss_tot > 0 else 0.0
    
    metrics = {
        "MAE": round(mae, 2),
        "RMSE": round(rmse, 2),
        "wMAPE (%)": round(wmape, 2),
        "MAPE (%)": round(mape, 2),
        "MAPE_pos (%)": round(mape_positive_only, 2),
        "R2": round(r2, 4)
    }
    
    # Bayesian Interval Coverage & Winkler Scores
    if y_lower_80 is not None and y_upper_80 is not None:
        y_l80 = np.asarray(y_lower_80, dtype=float)
        y_u80 = np.asarray(y_upper_80, dtype=float)
        in_80 = (y_true >= y_l80) & (y_true <= y_u80)
        coverage_80 = float(np.mean(in_80) * 100.0)
        width_80 = float(np.mean(y_u80 - y_l80))
        metrics["Coverage_80 (%)"] = round(coverage_80, 1)
        metrics["Mean_Width_80"] = round(width_80, 2)
        
    if y_lower_95 is not None and y_upper_95 is not None:
        y_l95 = np.asarray(y_lower_95, dtype=float)
        y_u95 = np.asarray(y_upper_95, dtype=float)
        in_95 = (y_true >= y_l95) & (y_true <= y_u95)
        coverage_95 = float(np.mean(in_95) * 100.0)
        width_95 = float(np.mean(y_u95 - y_l95))
        
        # Winkler Interval Score for 95% (alpha = 0.05)
        # IS = (U - L) + (2/alpha)*(L - y)*I(y < L) + (2/alpha)*(y - U)*I(y > U)
        alpha = 0.05
        under = np.maximum(0.0, y_l95 - y_true)
        over = np.maximum(0.0, y_true - y_u95)
        winkler = (y_u95 - y_l95) + (2.0 / alpha) * under + (2.0 / alpha) * over
        metrics["Coverage_95 (%)"] = round(coverage_95, 1)
        metrics["Mean_Width_95"] = round(width_95, 2)
        metrics["Interval_Score_95"] = round(float(np.mean(winkler)), 2)
        
    return metrics


def compare_multiple_models(
    results_dict: Dict[str, pd.DataFrame],
    actual_col: str = "revenue",
    pred_col: str = "y_pred_mean"
) -> pd.DataFrame:
    """
    Compare multiple models side-by-side in a unified summary benchmark table.
    """
    rows = []
    for model_name, df_res in results_dict.items():
        if actual_col not in df_res.columns or pred_col not in df_res.columns:
            continue
            
        y_true = df_res[actual_col].values
        y_pred = df_res[pred_col].values
        
        y_l80 = df_res["ci_lower_80"].values if "ci_lower_80" in df_res.columns else None
        y_u80 = df_res["ci_upper_80"].values if "ci_upper_80" in df_res.columns else None
        y_l95 = df_res["ci_lower_95"].values if "ci_lower_95" in df_res.columns else None
        y_u95 = df_res["ci_upper_95"].values if "ci_upper_95" in df_res.columns else None
        
        m = compute_forecast_metrics(
            y_true=y_true,
            y_pred=y_pred,
            y_lower_80=y_l80,
            y_upper_80=y_u80,
            y_lower_95=y_l95,
            y_upper_95=y_u95
        )
        m["Model"] = model_name
        rows.append(m)
        
    res_df = pd.DataFrame(rows)
    if not res_df.empty:
        # Reorder Model column first
        cols = ["Model"] + [c for c in res_df.columns if c != "Model"]
        res_df = res_df[cols]
    return res_df
