"""
inventory.py
============
Retail Demand Planning & Inventory Optimization Engine:
  - Classical Normal Safety Stock & Reorder Point (ROP)
  - Bayesian Predictive Quantile-based Safety Stock & ROP
  - Economic Order Quantity (EOQ) and Total Cost Curve
  - Multi-period Dynamic Inventory Trajectory Simulator
  - Fill Rate (Type-2 Service Level) and Stockout Risk Analysis
"""

import numpy as np
import pandas as pd
from scipy.stats import norm
from typing import Dict, Any, Tuple, Optional, List

def calculate_classical_inventory_parameters(
    mean_weekly_demand: float,
    std_weekly_demand: float,
    lead_time_weeks: float = 2.0,
    lead_time_std_weeks: float = 0.4,
    service_level: float = 0.95,
    unit_cost: float = 25.0,
    holding_cost_annual_pct: float = 0.20,
    order_cost: float = 50.0,
    stockout_penalty_per_unit: float = 20.0
) -> Dict[str, Any]:
    """
    Compute classical inventory parameters using Normal lead-time demand assumptions.
    
    Formulas:
      sigma_DL = sqrt( L * sigma_D^2 + d^2 * sigma_L^2 )
      SS = Z_alpha * sigma_DL
      ROP = d * L + SS
      EOQ = sqrt( 2 * D_annual * S / H )
    """
    z = float(norm.ppf(service_level))
    
    # Combined demand and lead time uncertainty
    var_dl = (lead_time_weeks * (std_weekly_demand ** 2)) + ((mean_weekly_demand ** 2) * (lead_time_std_weeks ** 2))
    sigma_dl = float(np.sqrt(max(0.001, var_dl)))
    
    expected_lead_time_demand = float(mean_weekly_demand * lead_time_weeks)
    safety_stock = float(z * sigma_dl)
    reorder_point = float(expected_lead_time_demand + safety_stock)
    
    # Annual metrics
    annual_demand = float(mean_weekly_demand * 52)
    holding_cost_per_unit_year = float(unit_cost * holding_cost_annual_pct)
    
    eoq = float(np.sqrt((2 * annual_demand * order_cost) / (holding_cost_per_unit_year + 1e-6)))
    
    annual_orders = annual_demand / (eoq + 1e-6)
    annual_order_cost = annual_orders * order_cost
    annual_holding_cost = ((eoq / 2.0) + safety_stock) * holding_cost_per_unit_year
    
    # Expected units short per cycle under Normal assumption
    # EUS = sigma_dl * (pdf(z) - z * (1 - cdf(z)))
    eus = sigma_dl * (norm.pdf(z) - z * (1 - norm.cdf(z)))
    fill_rate = max(0.0, min(1.0, 1.0 - (eus / (eoq + 1e-6))))
    annual_stockout_cost = eus * annual_orders * stockout_penalty_per_unit
    
    total_cost = annual_order_cost + annual_holding_cost + annual_stockout_cost
    
    return {
        "service_level": service_level,
        "z_score": z,
        "mean_weekly_demand": mean_weekly_demand,
        "expected_lead_time_demand": expected_lead_time_demand,
        "lead_time_std": sigma_dl,
        "safety_stock": round(safety_stock, 1),
        "reorder_point": round(reorder_point, 1),
        "eoq": round(eoq, 1),
        "fill_rate": round(fill_rate * 100.0, 2),
        "annual_holding_cost": round(annual_holding_cost, 2),
        "annual_ordering_cost": round(annual_order_cost, 2),
        "annual_stockout_cost": round(annual_stockout_cost, 2),
        "total_annual_cost": round(total_cost, 2)
    }


def calculate_bayesian_inventory_parameters(
    predictive_samples: np.ndarray,
    lead_time_weeks: int = 2,
    service_level: float = 0.95,
    unit_cost: float = 25.0,
    holding_cost_annual_pct: float = 0.20,
    order_cost: float = 50.0,
    stockout_penalty_per_unit: float = 20.0
) -> Dict[str, Any]:
    """
    Compute Bayesian Uncertainty-Aware Inventory Parameters directly from
    MCMC / Posterior Predictive draws.
    
    Rather than assuming a symmetric Gaussian distribution, this empirical quantile
    approach directly accounts for parameter uncertainty, positive skewness,
    promotional tail risk, and fat-tailed shocks.
    """
    # predictive_samples shape: (n_draws, n_steps)
    if predictive_samples.ndim == 1:
        predictive_samples = predictive_samples.reshape(-1, 1)
        
    n_draws, n_steps = predictive_samples.shape
    eff_lead_time = min(lead_time_weeks, n_steps)
    
    # Cumulative lead time demand per MCMC sample
    lead_time_draws = np.sum(predictive_samples[:, :eff_lead_time], axis=1)
    if eff_lead_time < lead_time_weeks and eff_lead_time > 0:
        lead_time_draws = lead_time_draws * (lead_time_weeks / eff_lead_time)
    
    # Expected demand over lead time
    mean_lt_demand = float(np.mean(lead_time_draws))
    median_lt_demand = float(np.median(lead_time_draws))
    std_lt_demand = float(np.std(lead_time_draws))
    
    # Empirical quantile for target cycle service level
    bayesian_rop = float(np.quantile(lead_time_draws, service_level))
    bayesian_safety_stock = float(max(0.0, bayesian_rop - mean_lt_demand))
    
    # EOQ based on mean annual demand
    weekly_mean = mean_lt_demand / max(eff_lead_time, 1)
    annual_demand = weekly_mean * 52
    holding_cost_per_unit_year = unit_cost * holding_cost_annual_pct
    eoq = float(np.sqrt((2 * annual_demand * order_cost) / (holding_cost_per_unit_year + 1e-6)))
    
    # Empirical expected stockout units per cycle
    stockouts_per_draw = np.maximum(0.0, lead_time_draws - bayesian_rop)
    eus = float(np.mean(stockouts_per_draw))
    fill_rate = max(0.0, min(1.0, 1.0 - (eus / (eoq + 1e-6))))
    
    annual_orders = annual_demand / (eoq + 1e-6)
    annual_order_cost = annual_orders * order_cost
    annual_holding_cost = ((eoq / 2.0) + bayesian_safety_stock) * holding_cost_per_unit_year
    annual_stockout_cost = eus * annual_orders * stockout_penalty_per_unit
    total_cost = annual_order_cost + annual_holding_cost + annual_stockout_cost
    
    return {
        "service_level": service_level,
        "lead_time_weeks": eff_lead_time,
        "mean_lead_time_demand": round(mean_lt_demand, 1),
        "median_lead_time_demand": round(median_lt_demand, 1),
        "lead_time_demand_std": round(std_lt_demand, 1),
        "safety_stock": round(bayesian_safety_stock, 1),
        "reorder_point": round(bayesian_rop, 1),
        "eoq": round(eoq, 1),
        "expected_units_short": round(eus, 2),
        "fill_rate": round(fill_rate * 100.0, 2),
        "annual_holding_cost": round(annual_holding_cost, 2),
        "annual_ordering_cost": round(annual_order_cost, 2),
        "annual_stockout_cost": round(annual_stockout_cost, 2),
        "total_annual_cost": round(total_cost, 2),
        "lead_time_distribution": lead_time_draws
    }


def simulate_inventory_trajectory(
    demand_series: np.ndarray,
    reorder_point: float,
    order_quantity: float,
    lead_time_steps: int = 2,
    initial_stock: Optional[float] = None,
    unit_holding_cost: float = 0.50,
    unit_stockout_penalty: float = 15.0
) -> pd.DataFrame:
    """
    Simulate weekly inventory on hand, orders, shipments, and stockouts
    under a continuous review (s, Q) policy.
    """
    n_steps = len(demand_series)
    if initial_stock is None:
        initial_stock = reorder_point + order_quantity * 0.5
        
    stock_on_hand = np.zeros(n_steps)
    orders_placed = np.zeros(n_steps)
    orders_received = np.zeros(n_steps)
    stockouts = np.zeros(n_steps)
    holding_costs = np.zeros(n_steps)
    stockout_costs = np.zeros(n_steps)
    
    current_stock = float(initial_stock)
    in_transit = []  # tuples of (arrival_step, qty)
    
    for t in range(n_steps):
        # 1. Receive arriving orders
        arrived_qty = sum(qty for arr_t, qty in in_transit if arr_t == t)
        current_stock += arrived_qty
        orders_received[t] = arrived_qty
        in_transit = [(arr_t, qty) for arr_t, qty in in_transit if arr_t > t]
        
        # 2. Satisfy demand
        dem = float(demand_series[t])
        if current_stock >= dem:
            current_stock -= dem
            stockouts[t] = 0.0
        else:
            shortage = dem - current_stock
            stockouts[t] = shortage
            current_stock = 0.0
            
        stock_on_hand[t] = current_stock
        
        # 3. Check inventory position and trigger order if IP <= ROP
        # Inventory Position = Stock on hand + In Transit
        inventory_pos = current_stock + sum(qty for _, qty in in_transit)
        if inventory_pos <= reorder_point:
            orders_placed[t] = order_quantity
            in_transit.append((t + lead_time_steps, order_quantity))
            
        # Costs
        holding_costs[t] = current_stock * unit_holding_cost
        stockout_costs[t] = stockouts[t] * unit_stockout_penalty

    df_sim = pd.DataFrame({
        "week_step": np.arange(1, n_steps + 1),
        "actual_demand": demand_series,
        "stock_on_hand": stock_on_hand,
        "orders_placed": orders_placed,
        "orders_received": orders_received,
        "stockouts": stockouts,
        "holding_cost": holding_costs,
        "stockout_cost": stockout_costs
    })
    return df_sim


def generate_service_level_tradeoff_curve(
    predictive_samples: np.ndarray,
    lead_time_weeks: int = 2,
    service_levels: List[float] = [0.80, 0.85, 0.90, 0.92, 0.95, 0.97, 0.98, 0.99, 0.995],
    unit_cost: float = 25.0,
    holding_cost_annual_pct: float = 0.20,
    order_cost: float = 50.0,
    stockout_penalty_per_unit: float = 20.0
) -> pd.DataFrame:
    """
    Compute inventory costs across a spectrum of service levels to illustrate
    the nonlinear 'hockey stick' cost curve of high safety stock.
    """
    rows = []
    for sl in service_levels:
        res = calculate_bayesian_inventory_parameters(
            predictive_samples=predictive_samples,
            lead_time_weeks=lead_time_weeks,
            service_level=sl,
            unit_cost=unit_cost,
            holding_cost_annual_pct=holding_cost_annual_pct,
            order_cost=order_cost,
            stockout_penalty_per_unit=stockout_penalty_per_unit
        )
        rows.append({
            "Service_Level_Pct": sl * 100.0,
            "Safety_Stock": res["safety_stock"],
            "Reorder_Point": res["reorder_point"],
            "Annual_Holding_Cost": res["annual_holding_cost"],
            "Annual_Stockout_Cost": res["annual_stockout_cost"],
            "Annual_Ordering_Cost": res["annual_ordering_cost"],
            "Total_Annual_Cost": res["total_annual_cost"]
        })
    return pd.DataFrame(rows)
