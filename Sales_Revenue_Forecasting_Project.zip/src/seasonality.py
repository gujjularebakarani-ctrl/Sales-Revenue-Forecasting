"""
seasonality.py
==============
Multi-scale Seasonality Analysis Module:
  - Classical Additive & Multiplicative Decomposition (Trend, Seasonality, Residual)
  - Monthly Seasonality Index & Intra-year Dynamics
  - Quarterly Revenue Distribution
  - Weekly / Annual Fourier Harmonic Spectrum
  - Holiday Impact and Category-level Seasonal Variations
"""

import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import seasonal_decompose
from typing import Dict, Any, Tuple, Optional, List

def perform_seasonal_decomposition(
    df: pd.DataFrame,
    target_col: str = "revenue",
    period: int = 52,
    model: str = "additive"
) -> Dict[str, Any]:
    """
    Decompose time series into Trend, Seasonal, and Residual components
    using classical moving-average decomposition.
    """
    ts = df.sort_values("date").set_index("date")[target_col]
    # Impute or ensure non-zero if multiplicative
    if model == "multiplicative":
        ts = ts.replace(0, 1.0)
        
    n = len(ts)
    if n < 4:
        decomp_df = pd.DataFrame({
            "date": ts.index,
            "observed": ts.values,
            "trend": ts.values,
            "seasonal": np.zeros(n),
            "residual": np.zeros(n)
        })
        return {
            "model": model,
            "period": 1,
            "decomposition_df": decomp_df,
            "seasonal_strength": 0.0,
            "trend_strength": 1.0
        }
        
    if n < 2 * period:
        # If insufficient periods for annual 52-week, use smaller period (at most n//2)
        effective_period = max(2, min(12, n // 2))
    else:
        effective_period = period
        
    decomp = seasonal_decompose(ts, model=model, period=effective_period, extrapolate_trend="period")
    
    decomp_df = pd.DataFrame({
        "date": ts.index,
        "observed": decomp.observed.values,
        "trend": decomp.trend.values,
        "seasonal": decomp.seasonal.values,
        "residual": decomp.resid.values
    })
    
    return {
        "model": model,
        "period": effective_period,
        "decomposition_df": decomp_df,
        "seasonal_strength": float(max(0.0, 1.0 - np.var(decomp.resid.dropna()) / (np.var(decomp.seasonal + decomp.resid.dropna()) + 1e-6))),
        "trend_strength": float(max(0.0, 1.0 - np.var(decomp.resid.dropna()) / (np.var(decomp.trend.dropna() + decomp.resid.dropna()) + 1e-6)))
    }


def compute_monthly_seasonality(df: pd.DataFrame, target_col: str = "revenue") -> pd.DataFrame:
    """
    Calculate monthly seasonality indices, showing percentage deviation
    from average monthly sales.
    """
    work = df.copy()
    work["date"] = pd.to_datetime(work["date"])
    work["month"] = work["date"].dt.month
    work["month_name"] = work["date"].dt.strftime("%b")
    
    # Monthly aggregation
    monthly = work.groupby(["month", "month_name"])[target_col].agg(["mean", "std", "median", "count"]).reset_index()
    grand_mean = monthly["mean"].mean()
    
    # Seasonality index: 1.0 = baseline, 1.25 = +25% above average month
    monthly["seasonality_index"] = monthly["mean"] / (grand_mean + 1e-6)
    monthly["pct_deviation"] = (monthly["seasonality_index"] - 1.0) * 100.0
    
    # Sort Jan - Dec
    monthly = monthly.sort_values("month").reset_index(drop=True)
    return monthly


def compute_quarterly_seasonality(df: pd.DataFrame, target_col: str = "revenue") -> pd.DataFrame:
    """
    Calculate quarterly performance distribution and seasonal multipliers.
    """
    work = df.copy()
    work["date"] = pd.to_datetime(work["date"])
    work["quarter"] = "Q" + work["date"].dt.quarter.astype(str)
    
    quarterly = work.groupby("quarter")[target_col].agg(["sum", "mean", "std"]).reset_index()
    total_rev = quarterly["sum"].sum()
    quarterly["revenue_share_pct"] = (quarterly["sum"] / (total_rev + 1e-6)) * 100.0
    grand_mean = quarterly["mean"].mean()
    quarterly["quarterly_index"] = quarterly["mean"] / (grand_mean + 1e-6)
    
    return quarterly.sort_values("quarter").reset_index(drop=True)


def compute_fourier_spectrum(df: pd.DataFrame, target_col: str = "revenue") -> pd.DataFrame:
    """
    Compute Fast Fourier Transform (FFT) power spectral density
    to identify dominant cyclical periodicities in the demand series.
    """
    y = df.sort_values("date")[target_col].values
    n = len(y)
    if n < 8:
        return pd.DataFrame()
        
    # Detrend using linear fit
    x = np.arange(n)
    trend = np.polyval(np.polyfit(x, y, 1), x)
    detrended = y - trend
    
    # FFT
    fft_vals = np.fft.rfft(detrended)
    freqs = np.fft.rfftfreq(n, d=1.0)  # cycles per week
    power = np.abs(fft_vals) ** 2
    
    # Periods in weeks (avoid divide by zero warning)
    safe_freqs = np.where(freqs > 0, freqs, 1.0)
    periods = np.where(freqs > 0, 1.0 / safe_freqs, np.nan)
    
    spectrum_df = pd.DataFrame({
        "frequency": freqs[1:],
        "period_weeks": periods[1:],
        "power": power[1:]
    })
    
    spectrum_df = spectrum_df.dropna().sort_values("power", ascending=False).reset_index(drop=True)
    return spectrum_df.head(10)


def compute_holiday_promotional_lift(df: pd.DataFrame, target_col: str = "revenue") -> Dict[str, Any]:
    """
    Quantify sales lift under holiday events and promotional interventions.
    """
    has_holiday = "holiday_flag" in df.columns
    has_promo = "on_promotion" in df.columns
    
    results = {}
    if has_holiday:
        h_mean = df[df["holiday_flag"] == 1][target_col].mean()
        non_h_mean = df[df["holiday_flag"] == 0][target_col].mean()
        results["holiday_mean"] = float(h_mean) if not np.isnan(h_mean) else 0.0
        results["baseline_mean"] = float(non_h_mean) if not np.isnan(non_h_mean) else 0.0
        results["holiday_lift_pct"] = float(((h_mean / (non_h_mean + 1e-6)) - 1.0) * 100.0) if non_h_mean else 0.0
        
    if has_promo:
        p_mean = df[df["on_promotion"] == 1][target_col].mean()
        non_p_mean = df[df["on_promotion"] == 0][target_col].mean()
        results["promo_mean"] = float(p_mean) if not np.isnan(p_mean) else 0.0
        results["non_promo_mean"] = float(non_p_mean) if not np.isnan(non_p_mean) else 0.0
        results["promo_lift_pct"] = float(((p_mean / (non_p_mean + 1e-6)) - 1.0) * 100.0) if non_p_mean else 0.0
        
    return results
