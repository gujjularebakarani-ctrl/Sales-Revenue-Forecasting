"""
visualization.py
================
Modern, responsive, publication-grade interactive Plotly visualizations
for the Retail Sales & Revenue Forecasting Dashboard.
"""

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, List

# Aesthetic Color Palette (Tailwind Dark Modern Palette)
THEME_COLORS = {
    "background": "#0F172A",
    "card": "#1E293B",
    "text": "#F8FAFC",
    "subtext": "#94A3B8",
    "primary": "#3B82F6",       # Blue
    "secondary": "#8B5CF6",     # Purple
    "accent": "#10B981",        # Emerald Green
    "warning": "#F59E0B",       # Amber
    "danger": "#EF4444",        # Crimson
    "grid": "#334155",
    "ribbon_95": "rgba(59, 130, 246, 0.15)",
    "ribbon_80": "rgba(59, 130, 246, 0.25)",
    "ribbon_50": "rgba(59, 130, 246, 0.40)"
}

def apply_chart_theme(fig: go.Figure, title: str = "", height: int = 480) -> go.Figure:
    """Apply consistent dark modern aesthetic to Plotly figures."""
    fig.update_layout(
        title={
            "text": f"<b>{title}</b>" if title else "",
            "font": {"size": 17, "color": THEME_COLORS["text"], "family": "Inter, sans-serif"},
            "x": 0.02,
            "xanchor": "left"
        },
        paper_bgcolor=THEME_COLORS["card"],
        plot_bgcolor=THEME_COLORS["card"],
        font={"color": THEME_COLORS["text"], "family": "Inter, sans-serif"},
        height=height,
        margin={"l": 50, "r": 30, "t": 60, "b": 45},
        legend={
            "bgcolor": "rgba(15, 23, 42, 0.6)",
            "bordercolor": THEME_COLORS["grid"],
            "borderwidth": 1,
            "font": {"size": 12, "color": THEME_COLORS["text"]}
        },
        hovermode="x unified",
        xaxis=dict(
            gridcolor=THEME_COLORS["grid"],
            zerolinecolor=THEME_COLORS["grid"],
            tickfont={"color": THEME_COLORS["subtext"]}
        ),
        yaxis=dict(
            gridcolor=THEME_COLORS["grid"],
            zerolinecolor=THEME_COLORS["grid"],
            tickfont={"color": THEME_COLORS["subtext"]}
        )
    )
    return fig


def plot_forecast_with_credible_intervals(
    train_df: pd.DataFrame,
    pred_df: pd.DataFrame,
    actual_col: str = "revenue",
    title: str = "Bayesian Posterior Predictive Forecast & Uncertainty Ribbons"
) -> go.Figure:
    """
    Plot historical observations alongside out-of-sample Bayesian forecast
    with 50%, 80%, and 95% Credible Interval uncertainty ribbons.
    """
    fig = go.Figure()
    
    # 1. Historical Actuals (Train)
    fig.add_trace(go.Scatter(
        x=pd.to_datetime(train_df["date"]),
        y=train_df[actual_col],
        name="Historical Actuals",
        mode="lines+markers",
        line=dict(color="#CBD5E1", width=2),
        marker=dict(size=4)
    ))
    
    # 2. Test Actuals if present in pred_df
    if actual_col in pred_df.columns:
        fig.add_trace(go.Scatter(
            x=pd.to_datetime(pred_df["date"]),
            y=pred_df[actual_col],
            name="Ground Truth (Holdout)",
            mode="lines+markers",
            line=dict(color="#10B981", width=2.5),
            marker=dict(size=6, symbol="diamond")
        ))
        
    dates_pred = pd.to_datetime(pred_df["date"])
    
    # 3. 95% Credible Interval Ribbon
    if "ci_lower_95" in pred_df.columns and "ci_upper_95" in pred_df.columns:
        fig.add_trace(go.Scatter(
            x=list(dates_pred) + list(dates_pred)[::-1],
            y=list(pred_df["ci_upper_95"]) + list(pred_df["ci_lower_95"])[::-1],
            fill="toself",
            fillcolor=THEME_COLORS["ribbon_95"],
            line=dict(color="rgba(255,255,255,0)"),
            hoverinfo="skip",
            name="95% Credible Interval",
            showlegend=True
        ))
        
    # 4. 80% Credible Interval Ribbon
    if "ci_lower_80" in pred_df.columns and "ci_upper_80" in pred_df.columns:
        fig.add_trace(go.Scatter(
            x=list(dates_pred) + list(dates_pred)[::-1],
            y=list(pred_df["ci_upper_80"]) + list(pred_df["ci_lower_80"])[::-1],
            fill="toself",
            fillcolor=THEME_COLORS["ribbon_80"],
            line=dict(color="rgba(255,255,255,0)"),
            hoverinfo="skip",
            name="80% Credible Interval",
            showlegend=True
        ))
        
    # 5. 50% Credible Interval Ribbon
    if "ci_lower_50" in pred_df.columns and "ci_upper_50" in pred_df.columns:
        fig.add_trace(go.Scatter(
            x=list(dates_pred) + list(dates_pred)[::-1],
            y=list(pred_df["ci_upper_50"]) + list(pred_df["ci_lower_50"])[::-1],
            fill="toself",
            fillcolor=THEME_COLORS["ribbon_50"],
            line=dict(color="rgba(255,255,255,0)"),
            hoverinfo="skip",
            name="50% Credible Interval (IQR)",
            showlegend=True
        ))
        
    # 6. Posterior Median Point Forecast
    pred_col = "y_pred_median" if "y_pred_median" in pred_df.columns else "y_pred_mean"
    fig.add_trace(go.Scatter(
        x=dates_pred,
        y=pred_df[pred_col],
        name="Bayesian Median Forecast",
        mode="lines+markers",
        line=dict(color="#3B82F6", width=3, dash="solid"),
        marker=dict(size=5, color="#60A5FA")
    ))
    
    return apply_chart_theme(fig, title=title, height=500)


def plot_model_comparison(
    pred_dfs: Dict[str, pd.DataFrame],
    actual_col: str = "revenue",
    title: str = "Model Forecasts vs Ground Truth on Holdout Test Set"
) -> go.Figure:
    """Compare multiple models on holdout test set side-by-side."""
    fig = go.Figure()
    
    colors = {
        "Bayesian Hierarchical": "#3B82F6",
        "Ridge Regression": "#F59E0B",
        "Random Forest": "#8B5CF6",
        "Holt-Winters": "#EC4899"
    }
    
    # Add actuals from the first available df
    first_df = next(iter(pred_dfs.values()))
    if actual_col in first_df.columns:
        fig.add_trace(go.Scatter(
            x=pd.to_datetime(first_df["date"]),
            y=first_df[actual_col],
            name="Ground Truth Actual",
            mode="lines+markers",
            line=dict(color="#10B981", width=3),
            marker=dict(size=6, symbol="circle")
        ))
        
    for model_name, df_m in pred_dfs.items():
        color = colors.get(model_name, "#94A3B8")
        pred_col = "y_pred_median" if "y_pred_median" in df_m.columns else "y_pred_mean"
        fig.add_trace(go.Scatter(
            x=pd.to_datetime(df_m["date"]),
            y=df_m[pred_col],
            name=model_name,
            mode="lines+markers",
            line=dict(color=color, width=2.5, dash="dash" if "Bayesian" not in model_name else "solid"),
            marker=dict(size=4)
        ))
        
    return apply_chart_theme(fig, title=title, height=480)


def plot_seasonality_decomposition(decomp_dict: Dict[str, Any]) -> go.Figure:
    """Plot 4-panel seasonal decomposition (Observed, Trend, Seasonal, Residual)."""
    df = decomp_dict["decomposition_df"]
    
    fig = make_subplots(
        rows=4, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.06,
        subplot_titles=["Observed Demand", "Estimated Macro Trend", "Periodic Seasonal Wave", "Stochastic Residuals"]
    )
    
    dates = pd.to_datetime(df["date"])
    
    fig.add_trace(go.Scatter(x=dates, y=df["observed"], line=dict(color="#CBD5E1", width=1.8), name="Observed"), row=1, col=1)
    fig.add_trace(go.Scatter(x=dates, y=df["trend"], line=dict(color="#3B82F6", width=2.5), name="Trend"), row=2, col=1)
    fig.add_trace(go.Scatter(x=dates, y=df["seasonal"], line=dict(color="#10B981", width=2.0), name="Seasonal"), row=3, col=1)
    fig.add_trace(go.Scatter(x=dates, y=df["residual"], mode="markers", marker=dict(color="#F59E0B", size=3), name="Residual"), row=4, col=1)
    
    fig.update_layout(
        paper_bgcolor=THEME_COLORS["card"],
        plot_bgcolor=THEME_COLORS["card"],
        font={"color": THEME_COLORS["text"]},
        height=620,
        showlegend=False,
        margin={"l": 50, "r": 30, "t": 50, "b": 40}
    )
    fig.update_xaxes(gridcolor=THEME_COLORS["grid"], zerolinecolor=THEME_COLORS["grid"])
    fig.update_yaxes(gridcolor=THEME_COLORS["grid"], zerolinecolor=THEME_COLORS["grid"])
    return fig


def plot_monthly_seasonality(monthly_df: pd.DataFrame) -> go.Figure:
    """Plot monthly seasonality index bar chart with baseline benchmark."""
    fig = go.Figure()
    
    colors = ["#10B981" if dev >= 0 else "#EF4444" for dev in monthly_df["pct_deviation"]]
    
    fig.add_trace(go.Bar(
        x=monthly_df["month_name"],
        y=monthly_df["pct_deviation"],
        marker_color=colors,
        text=[f"{v:+.1f}%" for v in monthly_df["pct_deviation"]],
        textposition="outside",
        name="Deviation from Mean"
    ))
    
    fig.add_hline(y=0, line_dash="dash", line_color="#94A3B8")
    
    fig.update_layout(
        title="<b>Monthly Seasonality Deviation (% Above/Below Baseline Average)</b>",
        yaxis_title="Deviation (%)",
        xaxis_title="Month"
    )
    return apply_chart_theme(fig, height=420)


def plot_inventory_trajectory(sim_df: pd.DataFrame, reorder_point: float) -> go.Figure:
    """Plot inventory levels, reorder threshold, order events, and stockouts."""
    fig = go.Figure()
    
    # Stock on hand line
    fig.add_trace(go.Scatter(
        x=sim_df["week_step"],
        y=sim_df["stock_on_hand"],
        name="Stock on Hand",
        mode="lines+markers",
        line=dict(color="#3B82F6", width=2.5),
        marker=dict(size=4)
    ))
    
    # Reorder Point threshold
    fig.add_hline(
        y=reorder_point,
        line_dash="dot",
        line_color="#F59E0B",
        annotation_text=f"Reorder Point ({reorder_point:.0f})",
        annotation_position="top left",
        annotation_font_color="#F59E0B"
    )
    
    # Orders Placed markers
    placed = sim_df[sim_df["orders_placed"] > 0]
    if not placed.empty:
        fig.add_trace(go.Scatter(
            x=placed["week_step"],
            y=placed["stock_on_hand"],
            name="Replenishment Order Triggered",
            mode="markers",
            marker=dict(size=10, color="#8B5CF6", symbol="triangle-up")
        ))
        
    # Stockouts bars
    stockouts = sim_df[sim_df["stockouts"] > 0]
    if not stockouts.empty:
        fig.add_trace(go.Bar(
            x=stockouts["week_step"],
            y=stockouts["stockouts"],
            name="Stockout Shortage (Unmet Demand)",
            marker_color="#EF4444"
        ))
        
    fig.update_layout(
        xaxis_title="Simulation Time Horizon (Weeks)",
        yaxis_title="Units",
        title="<b>Dynamic Inventory Trajectory under Continuous Review (s, Q) Policy</b>"
    )
    return apply_chart_theme(fig, height=480)


def plot_service_level_cost_curve(tradeoff_df: pd.DataFrame) -> go.Figure:
    """Plot total annual cost curve across cycle service levels."""
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=tradeoff_df["Service_Level_Pct"],
        y=tradeoff_df["Annual_Holding_Cost"],
        name="Holding Cost",
        mode="lines",
        line=dict(color="#3B82F6", width=2, dash="dash")
    ))
    
    fig.add_trace(go.Scatter(
        x=tradeoff_df["Service_Level_Pct"],
        y=tradeoff_df["Annual_Stockout_Cost"],
        name="Stockout Penalty Cost",
        mode="lines",
        line=dict(color="#EF4444", width=2, dash="dash")
    ))
    
    fig.add_trace(go.Scatter(
        x=tradeoff_df["Service_Level_Pct"],
        y=tradeoff_df["Total_Annual_Cost"],
        name="Total Relevant Inventory Cost",
        mode="lines+markers",
        line=dict(color="#10B981", width=3.5),
        marker=dict(size=6)
    ))
    
    # Find minimum cost point
    min_idx = tradeoff_df["Total_Annual_Cost"].idxmin()
    best_row = tradeoff_df.loc[min_idx]
    
    fig.add_annotation(
        x=best_row["Service_Level_Pct"],
        y=best_row["Total_Annual_Cost"],
        text=f"Optimal Tradeoff: {best_row['Service_Level_Pct']:.1f}% SL<br>Cost: ${best_row['Total_Annual_Cost']:,.0f}",
        showarrow=True,
        arrowhead=2,
        arrowcolor="#10B981",
        font=dict(color="#10B981", size=12),
        bgcolor=THEME_COLORS["card"],
        bordercolor="#10B981"
    )
    
    fig.update_layout(
        xaxis_title="Cycle Service Level (%)",
        yaxis_title="Annual Cost ($)",
        title="<b>Annual Cost Optimization vs Target Service Level</b>"
    )
    return apply_chart_theme(fig, height=460)


def plot_hierarchical_shrinkage(shrink_df: pd.DataFrame) -> go.Figure:
    """Plot Bayesian shrinkage offsets for store and category levels."""
    fig = go.Figure()
    
    stores = shrink_df[shrink_df["Level"] == "Store"]
    cats = shrink_df[shrink_df["Level"] == "Category"]
    
    if not stores.empty:
        fig.add_trace(go.Scatter(
            x=stores["Shrinkage_Offset"],
            y=stores["Entity"],
            error_x=dict(type="data", array=stores["Uncertainty_Std"], color="#60A5FA", width=2),
            mode="markers",
            marker=dict(size=10, color="#3B82F6"),
            name="Store Hierarchy"
        ))
        
    if not cats.empty:
        fig.add_trace(go.Scatter(
            x=cats["Shrinkage_Offset"],
            y=cats["Entity"],
            error_x=dict(type="data", array=cats["Uncertainty_Std"], color="#C084FC", width=2),
            mode="markers",
            marker=dict(size=10, color="#8B5CF6"),
            name="Category Hierarchy"
        ))
        
    fig.add_vline(x=0, line_dash="dash", line_color="#94A3B8")
    
    fig.update_layout(
        xaxis_title="Posterior Random Effect Offset (Std Units from Mean)",
        yaxis_title="Hierarchical Entity",
        title="<b>Bayesian Hierarchical Shrinkage (Posterior Means & 1-Sigma Uncertainty)</b>"
    )
    return apply_chart_theme(fig, height=440)


def plot_lead_time_demand_distribution(
    lead_time_draws: np.ndarray,
    reorder_point: float,
    service_level: float
) -> go.Figure:
    """Plot posterior predictive distribution of lead-time demand with ROP cutoff."""
    fig = go.Figure()
    
    fig.add_trace(go.Histogram(
        x=lead_time_draws,
        nbinsx=40,
        marker_color="#3B82F6",
        opacity=0.75,
        name="Lead-Time Demand Draws"
    ))
    
    fig.add_vline(
        x=reorder_point,
        line_color="#10B981",
        line_width=3,
        annotation_text=f"ROP ({service_level*100:.0f}% SL): {reorder_point:.0f} units",
        annotation_position="top right",
        annotation_font_color="#10B981"
    )
    
    fig.update_layout(
        xaxis_title="Total Units Demanded During Lead Time",
        yaxis_title="MCMC Posterior Predictive Frequency",
        title="<b>Posterior Predictive Distribution of Lead-Time Demand (Uncertainty Quantification)</b>"
    )
    return apply_chart_theme(fig, height=440)
