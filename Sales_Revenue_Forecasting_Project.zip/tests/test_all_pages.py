"""
test_all_pages.py
=================
Automated validation of all 9 Streamlit dashboard pages using Streamlit AppTest.
Ensures every page renders cleanly without any exceptions or runtime errors.
"""

import pytest
import os
import sys

# Ensure root in pythonpath
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from streamlit.testing.v1 import AppTest

def test_page_1_home():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    assert len(at.exception) == 0, f"Exception on Home page: {at.exception}"

def test_page_2_data_overview():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    # Select Data Overview in sidebar radio
    at.sidebar.radio[0].set_value("Data Overview").run()
    assert len(at.exception) == 0, f"Exception on Data Overview page: {at.exception}"

def test_page_3_exploratory_analysis():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    at.sidebar.radio[0].set_value("Exploratory Analysis").run()
    assert len(at.exception) == 0, f"Exception on Exploratory Analysis page: {at.exception}"

def test_page_4_sales_forecasting():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    at.sidebar.radio[0].set_value("Sales Forecasting").run()
    assert len(at.exception) == 0, f"Exception on Sales Forecasting page: {at.exception}"

def test_page_5_bayesian_analysis():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    at.sidebar.radio[0].set_value("Bayesian Analysis").run()
    assert len(at.exception) == 0, f"Exception on Bayesian Analysis page: {at.exception}"

def test_page_6_seasonality_analysis():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    at.sidebar.radio[0].set_value("Seasonality Analysis").run()
    assert len(at.exception) == 0, f"Exception on Seasonality Analysis page: {at.exception}"

def test_page_7_inventory_optimization():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    at.sidebar.radio[0].set_value("Inventory Optimization").run()
    assert len(at.exception) == 0, f"Exception on Inventory Optimization page: {at.exception}"

def test_page_8_model_evaluation():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    at.sidebar.radio[0].set_value("Model Evaluation").run()
    assert len(at.exception) == 0, f"Exception on Model Evaluation page: {at.exception}"

def test_page_9_about_project():
    at = AppTest.from_file("app.py", default_timeout=30)
    at.run()
    at.sidebar.radio[0].set_value("About Project").run()
    assert len(at.exception) == 0, f"Exception on About Project page: {at.exception}"
