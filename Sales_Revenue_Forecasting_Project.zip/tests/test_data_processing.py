"""
test_data_processing.py
"""
import pytest
import pandas as pd
import numpy as np
import os
import sys

# Ensure src in pythonpath
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.data_processing import (
    load_and_validate_data,
    aggregate_sales_data,
    engineer_forecasting_features,
    split_train_test,
    format_date
)

def test_format_date_handles_timestamps_and_strings():
    # Test pandas Timestamp (the exact type that failed with TypeError previously)
    ts = pd.Timestamp("2023-05-18 14:30:00")
    assert format_date(ts) == "2023-05-18"
    
    # Test string input
    assert format_date("2023-05-18") == "2023-05-18"
    
    # Test datetime.date
    from datetime import date
    assert format_date(date(2023, 5, 18)) == "2023-05-18"
    
    # Test missing / NaT
    assert format_date(pd.NaT) == "N/A"
    assert format_date(None) == "N/A"


def test_load_and_validate_sample_data():
    csv_path = os.path.join(os.path.dirname(__file__), "..", "data", "retail_sales_sample.csv")
    assert os.path.exists(csv_path), "Sample CSV file does not exist."
    
    df, report = load_and_validate_data(csv_path)
    assert report["is_valid"] is True
    assert len(df) > 0
    assert "date" in df.columns
    assert "revenue" in df.columns
    assert "units_sold" in df.columns
    assert pd.api.types.is_datetime64_any_dtype(df["date"])

def test_missing_values_and_edge_cases():
    bad_df = pd.DataFrame({
        "date": ["2022-01-01", "not-a-date", "2022-01-15"],
        "store_id": ["S1", "S1", "S1"],
        "category": ["C1", "C1", "C1"],
        "units_sold": [10, np.nan, 20],
        "revenue": [100.0, 50.0, np.nan]
    })
    df_clean, report = load_and_validate_data(bad_df)
    assert report["is_valid"] is True
    assert len(df_clean) == 2  # dropped invalid date
    assert df_clean["units_sold"].isna().sum() == 0
    assert df_clean["revenue"].isna().sum() == 0

def test_aggregate_sales_data():
    csv_path = os.path.join(os.path.dirname(__file__), "..", "data", "retail_sales_sample.csv")
    df, _ = load_and_validate_data(csv_path)
    
    # Total enterprise weekly aggregation
    agg_total = aggregate_sales_data(df, freq="W-MON", group_by=None)
    assert "revenue" in agg_total.columns
    assert len(agg_total) == 156
    
    # Aggregation by Store and Category
    agg_hier = aggregate_sales_data(df, freq="W-MON", group_by=["store_id", "category"])
    assert "store_id" in agg_hier.columns
    assert "category" in agg_hier.columns
    assert len(agg_hier) == 156 * 4 * 4

def test_engineer_forecasting_features():
    csv_path = os.path.join(os.path.dirname(__file__), "..", "data", "retail_sales_sample.csv")
    df, _ = load_and_validate_data(csv_path)
    agg_total = aggregate_sales_data(df, freq="W-MON", group_by=None)
    
    feat_df = engineer_forecasting_features(agg_total, fourier_harmonics=2)
    assert "trend_t" in feat_df.columns
    assert "fourier_sin_1" in feat_df.columns
    assert "fourier_cos_1" in feat_df.columns
    assert "fourier_sin_2" in feat_df.columns
    assert "fourier_cos_2" in feat_df.columns
    assert "lag_1" in feat_df.columns
    assert "rolling_mean_4" in feat_df.columns
    assert feat_df.isna().sum().sum() == 0

def test_split_train_test():
    csv_path = os.path.join(os.path.dirname(__file__), "..", "data", "retail_sales_sample.csv")
    df, _ = load_and_validate_data(csv_path)
    agg_total = aggregate_sales_data(df, freq="W-MON", group_by=None)
    
    train, test = split_train_test(agg_total, test_periods=12)
    assert len(train) == 156 - 12
    assert len(test) == 12
    assert train["date"].max() < test["date"].min()
