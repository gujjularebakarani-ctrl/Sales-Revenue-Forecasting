"""
test_evaluation.py
"""
import pytest
import numpy as np
import pandas as pd
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.evaluation import compute_forecast_metrics, compare_multiple_models

def test_compute_forecast_metrics():
    y_true = np.array([100.0, 150.0, 200.0, 250.0])
    y_pred = np.array([110.0, 140.0, 210.0, 240.0])
    l80 = y_pred - 15.0
    u80 = y_pred + 15.0
    l95 = y_pred - 25.0
    u95 = y_pred + 25.0
    
    metrics = compute_forecast_metrics(
        y_true=y_true,
        y_pred=y_pred,
        y_lower_80=l80,
        y_upper_80=u80,
        y_lower_95=l95,
        y_upper_95=u95
    )
    assert metrics["MAE"] == 10.0
    assert metrics["RMSE"] == 10.0
    assert metrics["Coverage_80 (%)"] == 100.0
    assert metrics["Coverage_95 (%)"] == 100.0
    assert metrics["R2"] > 0.95

def test_zero_actual_handling():
    # Test dataset containing zeroes
    y_true = np.array([0.0, 50.0, 0.0, 100.0])
    y_pred = np.array([5.0, 48.0, 2.0, 95.0])
    
    metrics = compute_forecast_metrics(y_true=y_true, y_pred=y_pred)
    # Ensure no NaN or infinite division error
    assert not np.isnan(metrics["MAPE (%)"])
    assert not np.isinf(metrics["MAPE (%)"])
    assert not np.isnan(metrics["wMAPE (%)"])
    assert metrics["wMAPE (%)"] > 0

def test_compare_multiple_models():
    dates = pd.date_range("2023-01-01", periods=5, freq="W")
    df1 = pd.DataFrame({"date": dates, "revenue": [10, 20, 30, 40, 50], "y_pred_mean": [11, 19, 31, 39, 51]})
    df2 = pd.DataFrame({"date": dates, "revenue": [10, 20, 30, 40, 50], "y_pred_mean": [15, 25, 35, 45, 55]})
    
    comp_df = compare_multiple_models({
        "Model_A": df1,
        "Model_B": df2
    })
    assert len(comp_df) == 2
    assert "Model" in comp_df.columns
    assert "MAE" in comp_df.columns
    # Model A has lower MAE (1.0 vs 5.0)
    assert comp_df.loc[comp_df["Model"] == "Model_A", "MAE"].values[0] < comp_df.loc[comp_df["Model"] == "Model_B", "MAE"].values[0]
