"""
test_inventory.py
"""
import pytest
import numpy as np
import pandas as pd
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.inventory import (
    calculate_classical_inventory_parameters,
    calculate_bayesian_inventory_parameters,
    simulate_inventory_trajectory,
    generate_service_level_tradeoff_curve
)

def test_classical_inventory():
    res = calculate_classical_inventory_parameters(
        mean_weekly_demand=200.0,
        std_weekly_demand=35.0,
        lead_time_weeks=2.0,
        service_level=0.95
    )
    assert res["service_level"] == 0.95
    assert res["safety_stock"] > 0
    assert res["reorder_point"] > res["expected_lead_time_demand"]
    assert res["eoq"] > 0
    assert 0.0 <= res["fill_rate"] <= 100.0

def test_bayesian_inventory():
    # Synthetic MCMC draws: 500 draws x 4 steps
    np.random.seed(42)
    draws = np.random.gamma(shape=20, scale=10, size=(500, 4))
    
    res = calculate_bayesian_inventory_parameters(
        predictive_samples=draws,
        lead_time_weeks=2,
        service_level=0.95
    )
    assert res["reorder_point"] > res["mean_lead_time_demand"]
    assert res["safety_stock"] >= 0
    assert res["eoq"] > 0
    assert res["total_annual_cost"] > 0
    assert len(res["lead_time_distribution"]) == 500

def test_inventory_trajectory_simulation():
    np.random.seed(42)
    demands = np.random.normal(100, 15, size=26).clip(50, 180)
    rop = 240.0
    order_qty = 300.0
    
    sim_df = simulate_inventory_trajectory(
        demand_series=demands,
        reorder_point=rop,
        order_quantity=order_qty,
        lead_time_steps=2
    )
    assert len(sim_df) == 26
    assert "stock_on_hand" in sim_df.columns
    assert "stockouts" in sim_df.columns
    assert (sim_df["stock_on_hand"] >= 0).all()

def test_service_level_tradeoff_curve():
    np.random.seed(42)
    draws = np.random.normal(150, 20, size=(300, 4)).clip(50, 300)
    tradeoff = generate_service_level_tradeoff_curve(
        predictive_samples=draws,
        lead_time_weeks=2,
        service_levels=[0.80, 0.90, 0.95, 0.99]
    )
    assert len(tradeoff) == 4
    # Safety stock and holding cost should strictly increase with service level
    assert tradeoff["Safety_Stock"].is_monotonic_increasing
    assert tradeoff["Annual_Holding_Cost"].is_monotonic_increasing
    # Stockout cost should strictly decrease with service level
    assert tradeoff["Annual_Stockout_Cost"].is_monotonic_decreasing
