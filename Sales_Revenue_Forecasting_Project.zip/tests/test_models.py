"""
test_models.py
"""
import pytest
import pandas as pd
import numpy as np
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.data_processing import load_and_validate_data, aggregate_sales_data, engineer_forecasting_features, split_train_test
from src.baseline_models import RidgeBaselineForecaster, RandomForestBaselineForecaster, HoltWintersBaselineForecaster
from src.bayesian_model import BayesianHierarchicalForecaster

@pytest.fixture(scope="module")
def prepared_series():
    csv_path = os.path.join(os.path.dirname(__file__), "..", "data", "retail_sales_sample.csv")
    df, _ = load_and_validate_data(csv_path)
    agg = aggregate_sales_data(df, freq="W-MON", group_by=None)
    feats = engineer_forecasting_features(agg, fourier_harmonics=2)
    train, test = split_train_test(feats, test_periods=12)
    return train, test

def test_ridge_baseline(prepared_series):
    train, test = prepared_series
    model = RidgeBaselineForecaster(target_col="revenue")
    model.fit(train)
    preds = model.predict(test)
    
    assert len(preds) == len(test)
    assert "y_pred_mean" in preds.columns
    assert "ci_lower_95" in preds.columns
    assert "ci_upper_95" in preds.columns
    assert (preds["y_pred_mean"] >= 0).all()
    assert (preds["ci_upper_95"] >= preds["ci_lower_95"]).all()

def test_random_forest_baseline(prepared_series):
    train, test = prepared_series
    model = RandomForestBaselineForecaster(target_col="revenue", n_estimators=20)
    model.fit(train)
    preds = model.predict(test)
    
    assert len(preds) == len(test)
    assert "y_pred_mean" in preds.columns
    assert (preds["ci_upper_80"] >= preds["ci_lower_80"]).all()

def test_holt_winters_baseline(prepared_series):
    train, test = prepared_series
    model = HoltWintersBaselineForecaster(target_col="revenue", seasonal_periods=52)
    model.fit(train)
    preds = model.predict(test)
    
    assert len(preds) == len(test)
    assert "y_pred_mean" in preds.columns
    assert (preds["y_pred_mean"] > 0).all()

def test_bayesian_forecaster_fast_advi(prepared_series):
    train, test = prepared_series
    # Use fast advi inference for speedy unit testing
    bayes_model = BayesianHierarchicalForecaster(
        fourier_harmonics=2,
        target_col="revenue",
        inference_method="advi",
        draws=150,
        random_seed=42
    )
    idata = bayes_model.fit(train, verbose=False)
    assert idata is not None
    assert "posterior" in idata
    
    # Predict
    preds = bayes_model.predict(test, credible_levels=[0.50, 0.80, 0.95])
    assert len(preds) == len(test)
    assert "y_pred_mean" in preds.columns
    assert "y_pred_median" in preds.columns
    assert "ci_lower_95" in preds.columns
    assert "ci_upper_95" in preds.columns
    
    # Credible interval monotonicity: lower <= median <= upper
    assert (preds["ci_lower_95"] <= preds["y_pred_median"] + 1e-4).all()
    assert (preds["y_pred_median"] <= preds["ci_upper_95"] + 1e-4).all()
    assert (preds["ci_lower_80"] <= preds["ci_upper_80"]).all()
    
    # Test diagnostics retrieval
    diag = bayes_model.get_diagnostics()
    assert "summary_df" in diag
    assert "inference_method" in diag
